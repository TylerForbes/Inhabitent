# WordPress MySQL database migration
#
# Generated: Wednesday 1. June 2016 17:59 UTC
# Hostname: localhost
# Database: `wpday1`
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `qwenjt_cfs_sessions`
#

DROP TABLE IF EXISTS `qwenjt_cfs_sessions`;


#
# Table structure of table `qwenjt_cfs_sessions`
#

CREATE TABLE `qwenjt_cfs_sessions` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `data` text,
  `expires` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `qwenjt_cfs_sessions`
#
INSERT INTO `qwenjt_cfs_sessions` ( `id`, `data`, `expires`) VALUES
('030c39db7f0e7b5942b39a2b797af2f1', 'a:7:{s:7:"post_id";i:108;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:90;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464817588'),
('1b2a0b686ec608d4cab9e5e8f7fc0dea', 'a:7:{s:7:"post_id";i:118;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:90;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464817498'),
('1ec4b12234dff93b43ae97b7b8b58b65', 'a:7:{s:7:"post_id";i:108;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:90;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464817612'),
('2449e63cb875df435e1d01475cf429cd', 'a:7:{s:7:"post_id";i:112;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:90;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464817563'),
('30ba921e780031c32d72ec3df8897c95', 'a:7:{s:7:"post_id";i:112;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:90;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464817577'),
('3a5d80ededba4e27d8b3112043870cce', 'a:7:{s:7:"post_id";i:110;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:90;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464817586'),
('47bb40481b93928ee22f21c050fdad96', 'a:7:{s:7:"post_id";i:114;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:90;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464817554'),
('642c2bcabe31234807e2a9692d2bee6e', 'a:7:{s:7:"post_id";i:110;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:90;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464817602'),
('716b3f92d68f4b021082c7a72efb7a2f', 'a:7:{s:7:"post_id";i:110;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:90;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464817631'),
('74833dedd47b3df6e06c31aebf1f22e0', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:90;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464817531'),
('767b8abfbb48dfe89844264c2c7262fd', 'a:7:{s:7:"post_id";i:114;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:90;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464817541'),
('7cb843b565e0391b78dea6bbfdcb3aef', 'a:7:{s:7:"post_id";i:116;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:90;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464817520'),
('9952ad2601d51d4cebeff70aa0205eff', 'a:7:{s:7:"post_id";i:106;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:90;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464817589'),
('c8de9e14de7179744da04a52bbabfbee', 'a:7:{s:7:"post_id";i:118;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:90;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464817510'),
('d25191d1f8ce7ce95f01dc5e6c8e1e50', 'a:7:{s:7:"post_id";i:106;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:90;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464817628') ;

#
# End of data contents of table `qwenjt_cfs_sessions`
# --------------------------------------------------------



#
# Delete any existing table `qwenjt_cfs_values`
#

DROP TABLE IF EXISTS `qwenjt_cfs_values`;


#
# Table structure of table `qwenjt_cfs_values`
#

CREATE TABLE `qwenjt_cfs_values` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `field_id` int(10) unsigned DEFAULT NULL,
  `meta_id` int(10) unsigned DEFAULT NULL,
  `post_id` int(10) unsigned DEFAULT NULL,
  `base_field_id` int(10) unsigned DEFAULT '0',
  `hierarchy` text,
  `depth` int(10) unsigned DEFAULT '0',
  `weight` int(10) unsigned DEFAULT '0',
  `sub_weight` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `field_id_idx` (`field_id`),
  KEY `post_id_idx` (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;


#
# Data contents of table `qwenjt_cfs_values`
#
INSERT INTO `qwenjt_cfs_values` ( `id`, `field_id`, `meta_id`, `post_id`, `base_field_id`, `hierarchy`, `depth`, `weight`, `sub_weight`) VALUES
(1, 1, 231, 88, 0, '', 0, 0, 0),
(33, 2, 446, 10, 0, '', 0, 0, 0),
(34, 3, 447, 10, 0, '', 0, 0, 0),
(35, 4, 448, 10, 0, '', 0, 0, 0),
(39, 1, 453, 136, 0, '', 0, 0, 0),
(40, 1, 456, 134, 0, '', 0, 0, 0),
(42, 1, 459, 132, 0, '', 0, 0, 0),
(43, 1, 461, 130, 0, '', 0, 0, 0),
(44, 1, 463, 128, 0, '', 0, 0, 0),
(45, 1, 465, 126, 0, '', 0, 0, 0),
(46, 1, 467, 124, 0, '', 0, 0, 0),
(47, 1, 469, 122, 0, '', 0, 0, 0),
(49, 1, 472, 120, 0, '', 0, 0, 0),
(50, 1, 477, 118, 0, '', 0, 0, 0),
(51, 1, 479, 116, 0, '', 0, 0, 0),
(52, 1, 481, 114, 0, '', 0, 0, 0),
(53, 1, 483, 112, 0, '', 0, 0, 0),
(55, 1, 487, 108, 0, '', 0, 0, 0),
(56, 1, 489, 106, 0, '', 0, 0, 0),
(57, 1, 490, 110, 0, '', 0, 0, 0) ;

#
# End of data contents of table `qwenjt_cfs_values`
# --------------------------------------------------------



#
# Delete any existing table `qwenjt_commentmeta`
#

DROP TABLE IF EXISTS `qwenjt_commentmeta`;


#
# Table structure of table `qwenjt_commentmeta`
#

CREATE TABLE `qwenjt_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `qwenjt_commentmeta`
#

#
# End of data contents of table `qwenjt_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `qwenjt_comments`
#

DROP TABLE IF EXISTS `qwenjt_comments`;


#
# Table structure of table `qwenjt_comments`
#

CREATE TABLE `qwenjt_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `qwenjt_comments`
#
INSERT INTO `qwenjt_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2016-05-18 22:54:52', '2016-05-18 22:54:52', 'Hi, this is a comment.\nTo delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, 'post-trashed', '', '', 0, 0) ;

#
# End of data contents of table `qwenjt_comments`
# --------------------------------------------------------



#
# Delete any existing table `qwenjt_links`
#

DROP TABLE IF EXISTS `qwenjt_links`;


#
# Table structure of table `qwenjt_links`
#

CREATE TABLE `qwenjt_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `qwenjt_links`
#

#
# End of data contents of table `qwenjt_links`
# --------------------------------------------------------



#
# Delete any existing table `qwenjt_options`
#

DROP TABLE IF EXISTS `qwenjt_options`;


#
# Table structure of table `qwenjt_options`
#

CREATE TABLE `qwenjt_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=499 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `qwenjt_options`
#
INSERT INTO `qwenjt_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/student', 'yes'),
(2, 'home', 'http://localhost/student', 'yes'),
(3, 'blogname', 'Inhabitent', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'tylerlforbes@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:133:{s:11:"products/?$";s:27:"index.php?post_type=product";s:41:"products/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:36:"products/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:28:"products/page/([0-9]{1,})/?$";s:45:"index.php?post_type=product&paged=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:35:"product/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"product/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"product/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"product/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"product/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"product/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:24:"product/([^/]+)/embed/?$";s:40:"index.php?product=$matches[1]&embed=true";s:28:"product/([^/]+)/trackback/?$";s:34:"index.php?product=$matches[1]&tb=1";s:48:"product/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:43:"product/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:36:"product/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&paged=$matches[2]";s:43:"product/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&cpage=$matches[2]";s:32:"product/([^/]+)(?:/([0-9]+))?/?$";s:46:"index.php?product=$matches[1]&page=$matches[2]";s:24:"product/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"product/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"product/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"product/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"product/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:30:"product/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"product-type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?product-type=$matches[1]&feed=$matches[2]";s:48:"product-type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?product-type=$matches[1]&feed=$matches[2]";s:29:"product-type/([^/]+)/embed/?$";s:45:"index.php?product-type=$matches[1]&embed=true";s:41:"product-type/([^/]+)/page/?([0-9]{1,})/?$";s:52:"index.php?product-type=$matches[1]&paged=$matches[2]";s:23:"product-type/([^/]+)/?$";s:34:"index.php?product-type=$matches[1]";s:31:"cfs/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:41:"cfs/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:61:"cfs/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:"cfs/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:"cfs/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:37:"cfs/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:20:"cfs/([^/]+)/embed/?$";s:51:"index.php?post_type=cfs&name=$matches[1]&embed=true";s:24:"cfs/([^/]+)/trackback/?$";s:45:"index.php?post_type=cfs&name=$matches[1]&tb=1";s:32:"cfs/([^/]+)/page/?([0-9]{1,})/?$";s:58:"index.php?post_type=cfs&name=$matches[1]&paged=$matches[2]";s:39:"cfs/([^/]+)/comment-page-([0-9]{1,})/?$";s:58:"index.php?post_type=cfs&name=$matches[1]&cpage=$matches[2]";s:28:"cfs/([^/]+)(?:/([0-9]+))?/?$";s:57:"index.php?post_type=cfs&name=$matches[1]&page=$matches[2]";s:20:"cfs/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:30:"cfs/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:50:"cfs/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:"cfs/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:"cfs/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:26:"cfs/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=16&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:4:{i:0;s:47:"business-hours-widget/business-hours-widget.php";i:1;s:26:"custom-field-suite/cfs.php";i:2;s:60:"inhabitant-functionality-master/inhabitant-functionality.php";i:3;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'inhabitant', 'yes'),
(41, 'stylesheet', 'inhabitant', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '36686', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', 'America/Vancouver', 'yes'),
(83, 'page_for_posts', '18', 'yes'),
(84, 'page_on_front', '16', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '36686', 'yes'),
(92, 'qwenjt_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:7:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";i:6;s:18:"inhabitent-hours-2";}s:13:"array_version";i:3;}', 'yes'),
(99, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `qwenjt_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'cron', 'a:4:{i:1464821695;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1464821728;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1464822059;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(106, 'nonce_key', 'pa)`Ccl%9dfD8aUtOPQRm1xMpEuxc;PpKs]$Jk8sZh}@F:-.{!dh?2!s_mfoMHII', 'yes'),
(107, 'nonce_salt', '9RHT?,dF?10PPH|+`x<WKKW_sS:4>_CKHz|M=jcJ8Nn!^@Okvgsq?4s0ZQFL_~vx', 'yes'),
(116, 'auth_key', '8Qu4Iwu99,Sx>/2G52Mwj,G<u%pT$[?~bmEB:AIdbsQ;96XeNt}z 2t%6ZKYb0H,', 'yes'),
(117, 'auth_salt', '+X6eiS=kiyw_6g,7-eBeG2[6+WR!=HZ^uR4Q!*[EGLKh?b@MVo6.Ww$MvV_=Ls:Z', 'yes'),
(118, 'logged_in_key', '$?~rYrpge[@?t4-Oy5O]_dzGQjo}sbU#!-DSoAc;sVeW>Lg4`#t/+,[!p!tUQm`$', 'yes'),
(119, 'logged_in_salt', '(cFO7HbaAn?L6W|.{i10(f@E}8C x<@=hOXTro1 F,.BkvLR=6f9Act@sgy;^HxH', 'yes'),
(125, 'can_compress_scripts', '0', 'yes'),
(140, 'recently_activated', 'a:0:{}', 'yes'),
(146, 'WPLANG', '', 'yes'),
(155, 'wpcf7', 'a:2:{s:7:"version";s:5:"4.4.2";s:13:"bulk_validate";a:4:{s:9:"timestamp";d:1463587227;s:7:"version";s:5:"4.4.2";s:11:"count_valid";i:1;s:13:"count_invalid";i:0;}}', 'yes'),
(168, 'current_theme', 'RED Starter Theme', 'yes'),
(169, 'theme_mods_redstarter-master', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1463690615;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(170, 'theme_switched', '', 'yes'),
(189, 'theme_mods_twentysixteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1463690681;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(190, 'theme_mods_inhabitant', 'a:2:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:7:"primary";i:14;}}', 'yes'),
(214, 'category_children', 'a:0:{}', 'yes'),
(281, 'cfs_next_field_id', '5', 'yes'),
(282, 'cfs_version', '2.5.5', 'yes'),
(286, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(343, 'widget_inhabitent-hours', 'a:2:{i:2;a:4:{s:5:"title";s:14:"Business Hours";s:13:"monday_friday";s:6:"7 to 9";s:8:"saturday";s:6:"8 to 5";s:6:"sunday";s:6:"9 to 1";}s:12:"_multiwidget";i:1;}', 'yes'),
(384, 'product-type_children', 'a:0:{}', 'yes') ;

#
# End of data contents of table `qwenjt_options`
# --------------------------------------------------------



#
# Delete any existing table `qwenjt_postmeta`
#

DROP TABLE IF EXISTS `qwenjt_postmeta`;


#
# Table structure of table `qwenjt_postmeta`
#

CREATE TABLE `qwenjt_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=491 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `qwenjt_postmeta`
#
INSERT INTO `qwenjt_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2, 4, '_form', '<p>Your Name (required)<br />\n    [text* your-name] </p>\n\n<p>Your Email (required)<br />\n    [email* your-email] </p>\n\n<p>Subject<br />\n    [text your-subject] </p>\n\n<p>Your Message<br />\n    [textarea your-message] </p>\n\n<p>[submit "Send"]</p>'),
(3, 4, '_mail', 'a:8:{s:7:"subject";s:23:"wpday1 "[your-subject]"";s:6:"sender";s:36:"[your-name] <tylerlforbes@gmail.com>";s:4:"body";s:168:"From: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n--\nThis e-mail was sent from a contact form on wpday1 (http://localhost/student)";s:9:"recipient";s:22:"tylerlforbes@gmail.com";s:18:"additional_headers";s:22:"Reply-To: [your-email]";s:11:"attachments";s:0:"";s:8:"use_html";i:0;s:13:"exclude_blank";i:0;}'),
(4, 4, '_mail_2', 'a:9:{s:6:"active";b:0;s:7:"subject";s:23:"wpday1 "[your-subject]"";s:6:"sender";s:31:"wpday1 <tylerlforbes@gmail.com>";s:4:"body";s:110:"Message Body:\n[your-message]\n\n--\nThis e-mail was sent from a contact form on wpday1 (http://localhost/student)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:32:"Reply-To: tylerlforbes@gmail.com";s:11:"attachments";s:0:"";s:8:"use_html";i:0;s:13:"exclude_blank";i:0;}'),
(5, 4, '_messages', 'a:8:{s:12:"mail_sent_ok";s:45:"Thank you for your message. It has been sent.";s:12:"mail_sent_ng";s:71:"There was an error trying to send your message. Please try again later.";s:16:"validation_error";s:61:"One or more fields have an error. Please check and try again.";s:4:"spam";s:71:"There was an error trying to send your message. Please try again later.";s:12:"accept_terms";s:69:"You must accept the terms and conditions before sending your message.";s:16:"invalid_required";s:22:"The field is required.";s:16:"invalid_too_long";s:22:"The field is too long.";s:17:"invalid_too_short";s:23:"The field is too short.";}'),
(6, 4, '_additional_settings', NULL),
(7, 4, '_locale', 'en_US'),
(16, 8, '_edit_last', '1'),
(17, 8, '_edit_lock', '1463692414:1'),
(18, 10, '_edit_last', '1'),
(19, 10, '_edit_lock', '1464384018:1'),
(20, 12, '_edit_last', '1'),
(21, 12, '_edit_lock', '1463692488:1'),
(22, 14, '_edit_last', '1'),
(23, 14, '_edit_lock', '1464129518:1'),
(24, 16, '_edit_last', '1'),
(25, 16, '_edit_lock', '1463692531:1'),
(26, 18, '_edit_last', '1'),
(27, 18, '_edit_lock', '1464129431:1'),
(28, 20, '_edit_last', '1'),
(29, 20, '_edit_lock', '1463692573:1'),
(30, 22, '_edit_last', '1'),
(31, 22, '_edit_lock', '1463692598:1'),
(32, 24, '_edit_last', '1'),
(33, 24, '_edit_lock', '1463692620:1'),
(34, 26, '_edit_last', '1'),
(35, 26, '_edit_lock', '1463692641:1'),
(36, 28, '_edit_last', '1'),
(37, 28, '_edit_lock', '1463692665:1'),
(38, 1, '_wp_trash_meta_status', 'publish'),
(39, 1, '_wp_trash_meta_time', '1463692879'),
(40, 1, '_wp_desired_post_slug', 'hello-world'),
(41, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:"1";}'),
(42, 32, '_edit_last', '1'),
(43, 32, '_edit_lock', '1464802781:1'),
(46, 35, '_edit_last', '1'),
(47, 35, '_edit_lock', '1463693451:1'),
(50, 39, '_edit_last', '1'),
(51, 39, '_edit_lock', '1463693521:1'),
(53, 41, '_edit_last', '1'),
(54, 41, '_edit_lock', '1463693625:1'),
(57, 45, '_edit_last', '1'),
(58, 45, '_edit_lock', '1463693741:1'),
(60, 48, '_wp_attached_file', '2016/05/beach-bonfire.jpg'),
(61, 48, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3000;s:6:"height";i:2000;s:4:"file";s:25:"2016/05/beach-bonfire.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"beach-bonfire-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"beach-bonfire-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:25:"beach-bonfire-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"beach-bonfire-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(62, 49, '_wp_attached_file', '2016/05/canoe-girl.jpg'),
(63, 49, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3000;s:6:"height";i:2000;s:4:"file";s:22:"2016/05/canoe-girl.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"canoe-girl-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"canoe-girl-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"canoe-girl-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"canoe-girl-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(64, 50, '_wp_attached_file', '2016/05/mountain-hikers.jpg'),
(65, 50, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3000;s:6:"height";i:2000;s:4:"file";s:27:"2016/05/mountain-hikers.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"mountain-hikers-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"mountain-hikers-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"mountain-hikers-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:28:"mountain-hikers-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(66, 51, '_wp_attached_file', '2016/05/night-sky.jpg'),
(67, 51, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3000;s:6:"height";i:2000;s:4:"file";s:21:"2016/05/night-sky.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"night-sky-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"night-sky-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:21:"night-sky-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:22:"night-sky-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(68, 52, '_wp_attached_file', '2016/05/glamping.jpg'),
(69, 52, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:20:"2016/05/glamping.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"glamping-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"glamping-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:20:"glamping-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"glamping-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(70, 53, '_wp_attached_file', '2016/05/healthy-camp-food.jpg'),
(71, 53, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:29:"2016/05/healthy-camp-food.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"healthy-camp-food-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:29:"healthy-camp-food-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:29:"healthy-camp-food-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:30:"healthy-camp-food-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(72, 54, '_wp_attached_file', '2016/05/solo-camping.jpg'),
(73, 54, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2515;s:6:"height";i:1830;s:4:"file";s:24:"2016/05/solo-camping.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"solo-camping-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"solo-camping-300x218.jpg";s:5:"width";i:300;s:6:"height";i:218;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"solo-camping-768x559.jpg";s:5:"width";i:768;s:6:"height";i:559;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"solo-camping-1024x745.jpg";s:5:"width";i:1024;s:6:"height";i:745;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(74, 55, '_wp_attached_file', '2016/05/van-camper.jpg'),
(75, 55, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1026;s:4:"file";s:22:"2016/05/van-camper.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"van-camper-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"van-camper-300x205.jpg";s:5:"width";i:300;s:6:"height";i:205;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"van-camper-768x525.jpg";s:5:"width";i:768;s:6:"height";i:525;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"van-camper-1024x700.jpg";s:5:"width";i:1024;s:6:"height";i:700;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(76, 56, '_wp_attached_file', '2016/05/warm-cocktail.jpg'),
(77, 56, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:25:"2016/05/warm-cocktail.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"warm-cocktail-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"warm-cocktail-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:25:"warm-cocktail-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"warm-cocktail-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(78, 57, '_wp_attached_file', '2016/05/dark-wood.png'),
(79, 57, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:512;s:6:"height";i:512;s:4:"file";s:21:"2016/05/dark-wood.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"dark-wood-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:21:"dark-wood-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(80, 58, '_wp_attached_file', '2016/05/dark-wood@2x.png'),
(81, 58, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1024;s:6:"height";i:1024;s:4:"file";s:24:"2016/05/dark-wood@2x.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"dark-wood@2x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:24:"dark-wood@2x-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:24:"dark-wood@2x-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(82, 59, '_wp_attached_file', '2016/05/home-hero.jpg'),
(83, 59, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3600;s:6:"height";i:2404;s:4:"file";s:21:"2016/05/home-hero.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"home-hero-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"home-hero-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:21:"home-hero-768x513.jpg";s:5:"width";i:768;s:6:"height";i:513;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:22:"home-hero-1024x684.jpg";s:5:"width";i:1024;s:6:"height";i:684;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(84, 60, '_wp_attached_file', '2016/05/beach-tent.jpg'),
(85, 60, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1950;s:4:"file";s:22:"2016/05/beach-tent.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"beach-tent-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"beach-tent-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"beach-tent-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"beach-tent-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(86, 61, '_wp_attached_file', '2016/05/camper-van.jpg'),
(87, 61, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:1125;s:4:"file";s:22:"2016/05/camper-van.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"camper-van-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"camper-van-300x169.jpg";s:5:"width";i:300;s:6:"height";i:169;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"camper-van-768x432.jpg";s:5:"width";i:768;s:6:"height";i:432;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"camper-van-1024x576.jpg";s:5:"width";i:1024;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(88, 62, '_wp_attached_file', '2016/05/ceramic-mugs.jpg'),
(89, 62, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:24:"2016/05/ceramic-mugs.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"ceramic-mugs-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"ceramic-mugs-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"ceramic-mugs-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"ceramic-mugs-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(90, 63, '_wp_attached_file', '2016/05/film-cameras.jpg'),
(91, 63, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1950;s:4:"file";s:24:"2016/05/film-cameras.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"film-cameras-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"film-cameras-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"film-cameras-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"film-cameras-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(92, 64, '_wp_attached_file', '2016/05/flannel-shirt.jpg'),
(93, 64, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1722;s:4:"file";s:25:"2016/05/flannel-shirt.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"flannel-shirt-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"flannel-shirt-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:25:"flannel-shirt-768x509.jpg";s:5:"width";i:768;s:6:"height";i:509;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"flannel-shirt-1024x678.jpg";s:5:"width";i:1024;s:6:"height";i:678;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(94, 65, '_wp_attached_file', '2016/05/gas-stove.jpg'),
(95, 65, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1722;s:4:"file";s:21:"2016/05/gas-stove.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"gas-stove-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"gas-stove-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:21:"gas-stove-768x509.jpg";s:5:"width";i:768;s:6:"height";i:509;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:22:"gas-stove-1024x678.jpg";s:5:"width";i:1024;s:6:"height";i:678;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(96, 66, '_wp_attached_file', '2016/05/hand-knit-toque.jpg'),
(97, 66, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1845;s:4:"file";s:27:"2016/05/hand-knit-toque.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"hand-knit-toque-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"hand-knit-toque-300x213.jpg";s:5:"width";i:300;s:6:"height";i:213;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"hand-knit-toque-768x545.jpg";s:5:"width";i:768;s:6:"height";i:545;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:28:"hand-knit-toque-1024x727.jpg";s:5:"width";i:1024;s:6:"height";i:727;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(98, 67, '_wp_attached_file', '2016/05/hiking-boots.jpg'),
(99, 67, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2376;s:6:"height";i:1782;s:4:"file";s:24:"2016/05/hiking-boots.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"hiking-boots-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"hiking-boots-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"hiking-boots-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"hiking-boots-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(100, 68, '_wp_attached_file', '2016/05/large-thermos.jpg'),
(101, 68, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1722;s:4:"file";s:25:"2016/05/large-thermos.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"large-thermos-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"large-thermos-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:25:"large-thermos-768x509.jpg";s:5:"width";i:768;s:6:"height";i:509;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"large-thermos-1024x678.jpg";s:5:"width";i:1024;s:6:"height";i:678;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(102, 69, '_wp_attached_file', '2016/05/leather-satchel.jpg'),
(103, 69, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:27:"2016/05/leather-satchel.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"leather-satchel-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"leather-satchel-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"leather-satchel-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:28:"leather-satchel-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(104, 70, '_wp_attached_file', '2016/05/nylon-tents.jpg'),
(105, 70, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1732;s:4:"file";s:23:"2016/05/nylon-tents.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"nylon-tents-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"nylon-tents-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"nylon-tents-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"nylon-tents-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(106, 71, '_wp_attached_file', '2016/05/rustic-tools.jpg'),
(107, 71, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:2111;s:4:"file";s:24:"2016/05/rustic-tools.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"rustic-tools-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"rustic-tools-300x244.jpg";s:5:"width";i:300;s:6:"height";i:244;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"rustic-tools-768x624.jpg";s:5:"width";i:768;s:6:"height";i:624;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"rustic-tools-1024x831.jpg";s:5:"width";i:1024;s:6:"height";i:831;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(108, 72, '_wp_attached_file', '2016/05/stew-can.jpg'),
(109, 72, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:20:"2016/05/stew-can.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"stew-can-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"stew-can-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:20:"stew-can-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"stew-can-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(110, 73, '_wp_attached_file', '2016/05/travel-hammock.jpg'),
(111, 73, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2288;s:6:"height";i:1520;s:4:"file";s:26:"2016/05/travel-hammock.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"travel-hammock-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"travel-hammock-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:26:"travel-hammock-768x510.jpg";s:5:"width";i:768;s:6:"height";i:510;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:27:"travel-hammock-1024x680.jpg";s:5:"width";i:1024;s:6:"height";i:680;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(112, 74, '_wp_attached_file', '2016/05/weathered-canoes.jpg'),
(113, 74, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:28:"2016/05/weathered-canoes.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"weathered-canoes-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"weathered-canoes-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:28:"weathered-canoes-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:29:"weathered-canoes-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(114, 75, '_wp_attached_file', '2016/05/wood-ax.jpg'),
(115, 75, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:19:"2016/05/wood-ax.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"wood-ax-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"wood-ax-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:19:"wood-ax-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:20:"wood-ax-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(116, 76, '_menu_item_type', 'post_type'),
(117, 76, '_menu_item_menu_item_parent', '0') ;
INSERT INTO `qwenjt_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(118, 76, '_menu_item_object_id', '16'),
(119, 76, '_menu_item_object', 'page'),
(120, 76, '_menu_item_target', ''),
(121, 76, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(122, 76, '_menu_item_xfn', ''),
(123, 76, '_menu_item_url', ''),
(124, 76, '_menu_item_orphaned', '1464121899'),
(125, 77, '_menu_item_type', 'post_type'),
(126, 77, '_menu_item_menu_item_parent', '0'),
(127, 77, '_menu_item_object_id', '8'),
(128, 77, '_menu_item_object', 'page'),
(129, 77, '_menu_item_target', ''),
(130, 77, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(131, 77, '_menu_item_xfn', ''),
(132, 77, '_menu_item_url', ''),
(133, 77, '_menu_item_orphaned', '1464121900'),
(134, 78, '_menu_item_type', 'post_type'),
(135, 78, '_menu_item_menu_item_parent', '0'),
(136, 78, '_menu_item_object_id', '10'),
(137, 78, '_menu_item_object', 'page'),
(138, 78, '_menu_item_target', ''),
(139, 78, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(140, 78, '_menu_item_xfn', ''),
(141, 78, '_menu_item_url', ''),
(142, 78, '_menu_item_orphaned', '1464121900'),
(143, 79, '_menu_item_type', 'post_type'),
(144, 79, '_menu_item_menu_item_parent', '0'),
(145, 79, '_menu_item_object_id', '12'),
(146, 79, '_menu_item_object', 'page'),
(147, 79, '_menu_item_target', ''),
(148, 79, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(149, 79, '_menu_item_xfn', ''),
(150, 79, '_menu_item_url', ''),
(151, 79, '_menu_item_orphaned', '1464121901'),
(152, 80, '_menu_item_type', 'post_type'),
(153, 80, '_menu_item_menu_item_parent', '0'),
(154, 80, '_menu_item_object_id', '14'),
(155, 80, '_menu_item_object', 'page'),
(156, 80, '_menu_item_target', ''),
(157, 80, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(158, 80, '_menu_item_xfn', ''),
(159, 80, '_menu_item_url', ''),
(160, 80, '_menu_item_orphaned', '1464121901'),
(161, 81, '_menu_item_type', 'post_type'),
(162, 81, '_menu_item_menu_item_parent', '0'),
(163, 81, '_menu_item_object_id', '16'),
(164, 81, '_menu_item_object', 'page'),
(165, 81, '_menu_item_target', ''),
(166, 81, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(167, 81, '_menu_item_xfn', ''),
(168, 81, '_menu_item_url', ''),
(169, 81, '_menu_item_orphaned', '1464121902'),
(170, 82, '_menu_item_type', 'post_type'),
(171, 82, '_menu_item_menu_item_parent', '0'),
(172, 82, '_menu_item_object_id', '18'),
(173, 82, '_menu_item_object', 'page'),
(174, 82, '_menu_item_target', ''),
(175, 82, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(176, 82, '_menu_item_xfn', ''),
(177, 82, '_menu_item_url', ''),
(178, 82, '_menu_item_orphaned', '1464121903'),
(179, 83, '_menu_item_type', 'post_type'),
(180, 83, '_menu_item_menu_item_parent', '0'),
(181, 83, '_menu_item_object_id', '20'),
(182, 83, '_menu_item_object', 'page'),
(183, 83, '_menu_item_target', ''),
(184, 83, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(185, 83, '_menu_item_xfn', ''),
(186, 83, '_menu_item_url', ''),
(187, 83, '_menu_item_orphaned', '1464121903'),
(188, 84, '_menu_item_type', 'post_type'),
(189, 84, '_menu_item_menu_item_parent', '0'),
(190, 84, '_menu_item_object_id', '22'),
(191, 84, '_menu_item_object', 'page'),
(192, 84, '_menu_item_target', ''),
(193, 84, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(194, 84, '_menu_item_xfn', ''),
(195, 84, '_menu_item_url', ''),
(196, 84, '_menu_item_orphaned', '1464121904'),
(197, 85, '_menu_item_type', 'post_type'),
(198, 85, '_menu_item_menu_item_parent', '0'),
(199, 85, '_menu_item_object_id', '24'),
(200, 85, '_menu_item_object', 'page'),
(201, 85, '_menu_item_target', ''),
(202, 85, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(203, 85, '_menu_item_xfn', ''),
(204, 85, '_menu_item_url', ''),
(205, 85, '_menu_item_orphaned', '1464121904'),
(206, 86, '_menu_item_type', 'post_type'),
(207, 86, '_menu_item_menu_item_parent', '0'),
(208, 86, '_menu_item_object_id', '26'),
(209, 86, '_menu_item_object', 'page'),
(210, 86, '_menu_item_target', ''),
(211, 86, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(212, 86, '_menu_item_xfn', ''),
(213, 86, '_menu_item_url', ''),
(214, 86, '_menu_item_orphaned', '1464121905'),
(215, 87, '_menu_item_type', 'post_type'),
(216, 87, '_menu_item_menu_item_parent', '0'),
(217, 87, '_menu_item_object_id', '28') ;
INSERT INTO `qwenjt_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(218, 87, '_menu_item_object', 'page'),
(219, 87, '_menu_item_target', ''),
(220, 87, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(221, 87, '_menu_item_xfn', ''),
(222, 87, '_menu_item_url', ''),
(223, 87, '_menu_item_orphaned', '1464121906'),
(224, 88, '_edit_last', '1'),
(225, 88, '_edit_lock', '1464126248:1'),
(226, 90, '_edit_last', '1'),
(227, 90, '_edit_lock', '1464126160:1'),
(228, 90, 'cfs_fields', 'a:1:{i:0;a:8:{s:2:"id";i:1;s:4:"name";s:5:"price";s:5:"label";s:5:"Price";s:4:"type";s:4:"text";s:5:"notes";s:30:"Enter a price for the product.";s:9:"parent_id";i:0;s:6:"weight";i:0;s:7:"options";a:2:{s:13:"default_value";s:0:"";s:8:"required";s:1:"0";}}}'),
(229, 90, 'cfs_rules', 'a:1:{s:10:"post_types";a:2:{s:8:"operator";s:2:"==";s:6:"values";a:1:{i:0;s:7:"product";}}}'),
(230, 90, 'cfs_extras', 'a:3:{s:5:"order";s:1:"0";s:7:"context";s:6:"normal";s:11:"hide_editor";s:1:"0";}'),
(231, 88, 'price', '$44.95'),
(232, 8, '_wp_trash_meta_status', 'publish'),
(233, 8, '_wp_trash_meta_time', '1464127634'),
(234, 8, '_wp_desired_post_slug', '404-page'),
(235, 20, '_wp_trash_meta_status', 'publish'),
(236, 20, '_wp_trash_meta_time', '1464127634'),
(237, 20, '_wp_desired_post_slug', 'product-type-archive-page'),
(238, 24, '_wp_trash_meta_status', 'publish'),
(239, 24, '_wp_trash_meta_time', '1464127634'),
(240, 24, '_wp_desired_post_slug', 'single-adventure-post'),
(241, 26, '_wp_trash_meta_status', 'publish'),
(242, 26, '_wp_trash_meta_time', '1464127635'),
(243, 26, '_wp_desired_post_slug', 'single-journal'),
(244, 28, '_wp_trash_meta_status', 'publish'),
(245, 28, '_wp_trash_meta_time', '1464127635'),
(246, 28, '_wp_desired_post_slug', 'single-product'),
(247, 12, '_wp_trash_meta_status', 'publish'),
(248, 12, '_wp_trash_meta_time', '1464127648'),
(249, 12, '_wp_desired_post_slug', 'adventures-archive-page'),
(250, 91, '_menu_item_type', 'post_type'),
(251, 91, '_menu_item_menu_item_parent', '0'),
(252, 91, '_menu_item_object_id', '16'),
(253, 91, '_menu_item_object', 'page'),
(254, 91, '_menu_item_target', ''),
(255, 91, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(256, 91, '_menu_item_xfn', ''),
(257, 91, '_menu_item_url', ''),
(258, 91, '_menu_item_orphaned', '1464129371'),
(259, 92, '_menu_item_type', 'post_type'),
(260, 92, '_menu_item_menu_item_parent', '0'),
(261, 92, '_menu_item_object_id', '10'),
(262, 92, '_menu_item_object', 'page'),
(263, 92, '_menu_item_target', ''),
(264, 92, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(265, 92, '_menu_item_xfn', ''),
(266, 92, '_menu_item_url', ''),
(267, 92, '_menu_item_orphaned', '1464129372'),
(268, 93, '_menu_item_type', 'post_type'),
(269, 93, '_menu_item_menu_item_parent', '0'),
(270, 93, '_menu_item_object_id', '14'),
(271, 93, '_menu_item_object', 'page'),
(272, 93, '_menu_item_target', ''),
(273, 93, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(274, 93, '_menu_item_xfn', ''),
(275, 93, '_menu_item_url', ''),
(276, 93, '_menu_item_orphaned', '1464129372'),
(277, 94, '_menu_item_type', 'post_type'),
(278, 94, '_menu_item_menu_item_parent', '0'),
(279, 94, '_menu_item_object_id', '16'),
(280, 94, '_menu_item_object', 'page'),
(281, 94, '_menu_item_target', ''),
(282, 94, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(283, 94, '_menu_item_xfn', ''),
(284, 94, '_menu_item_url', ''),
(285, 94, '_menu_item_orphaned', '1464129373'),
(286, 95, '_menu_item_type', 'post_type'),
(287, 95, '_menu_item_menu_item_parent', '0'),
(288, 95, '_menu_item_object_id', '18'),
(289, 95, '_menu_item_object', 'page'),
(290, 95, '_menu_item_target', ''),
(291, 95, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(292, 95, '_menu_item_xfn', ''),
(293, 95, '_menu_item_url', ''),
(294, 95, '_menu_item_orphaned', '1464129374'),
(295, 96, '_menu_item_type', 'post_type'),
(296, 96, '_menu_item_menu_item_parent', '0'),
(297, 96, '_menu_item_object_id', '22'),
(298, 96, '_menu_item_object', 'page'),
(299, 96, '_menu_item_target', ''),
(300, 96, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(301, 96, '_menu_item_xfn', ''),
(302, 96, '_menu_item_url', ''),
(303, 96, '_menu_item_orphaned', '1464129374'),
(313, 98, '_menu_item_type', 'post_type'),
(314, 98, '_menu_item_menu_item_parent', '0'),
(315, 98, '_menu_item_object_id', '10'),
(316, 98, '_menu_item_object', 'page'),
(317, 98, '_menu_item_target', ''),
(318, 98, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(319, 98, '_menu_item_xfn', ''),
(320, 98, '_menu_item_url', ''),
(322, 99, '_menu_item_type', 'post_type'),
(323, 99, '_menu_item_menu_item_parent', '0'),
(324, 99, '_menu_item_object_id', '14'),
(325, 99, '_menu_item_object', 'page'),
(326, 99, '_menu_item_target', ''),
(327, 99, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ;
INSERT INTO `qwenjt_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(328, 99, '_menu_item_xfn', ''),
(329, 99, '_menu_item_url', ''),
(331, 100, '_menu_item_type', 'post_type'),
(332, 100, '_menu_item_menu_item_parent', '0'),
(333, 100, '_menu_item_object_id', '16'),
(334, 100, '_menu_item_object', 'page'),
(335, 100, '_menu_item_target', ''),
(336, 100, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(337, 100, '_menu_item_xfn', ''),
(338, 100, '_menu_item_url', ''),
(339, 100, '_menu_item_orphaned', '1464129408'),
(340, 101, '_menu_item_type', 'post_type'),
(341, 101, '_menu_item_menu_item_parent', '0'),
(342, 101, '_menu_item_object_id', '18'),
(343, 101, '_menu_item_object', 'page'),
(344, 101, '_menu_item_target', ''),
(345, 101, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(346, 101, '_menu_item_xfn', ''),
(347, 101, '_menu_item_url', ''),
(349, 102, '_menu_item_type', 'post_type'),
(350, 102, '_menu_item_menu_item_parent', '0'),
(351, 102, '_menu_item_object_id', '22'),
(352, 102, '_menu_item_object', 'page'),
(353, 102, '_menu_item_target', ''),
(354, 102, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(355, 102, '_menu_item_xfn', ''),
(356, 102, '_menu_item_url', ''),
(357, 102, '_menu_item_orphaned', '1464129410'),
(358, 103, '_menu_item_type', 'custom'),
(359, 103, '_menu_item_menu_item_parent', '0'),
(360, 103, '_menu_item_object_id', '103'),
(361, 103, '_menu_item_object', 'custom'),
(362, 103, '_menu_item_target', ''),
(363, 103, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(364, 103, '_menu_item_xfn', ''),
(365, 103, '_menu_item_url', 'http://localhost/student/products'),
(367, 106, '_edit_last', '1'),
(368, 106, '_edit_lock', '1464803090:1'),
(370, 108, '_edit_last', '1'),
(371, 108, '_edit_lock', '1464803089:1'),
(374, 88, '_wp_trash_meta_status', 'publish'),
(375, 88, '_wp_trash_meta_time', '1464130480'),
(376, 88, '_wp_desired_post_slug', 'test-product'),
(377, 110, '_edit_last', '1'),
(378, 110, '_edit_lock', '1464803092:1'),
(380, 112, '_edit_last', '1'),
(381, 112, '_edit_lock', '1464803036:1'),
(383, 114, '_edit_last', '1'),
(384, 114, '_edit_lock', '1464803013:1'),
(386, 116, '_edit_last', '1'),
(387, 116, '_edit_lock', '1464802990:1'),
(389, 118, '_edit_last', '1'),
(390, 118, '_edit_lock', '1464802969:1'),
(392, 120, '_edit_last', '1'),
(393, 120, '_edit_lock', '1464556811:1'),
(395, 122, '_edit_last', '1'),
(396, 122, '_edit_lock', '1464556771:1'),
(398, 124, '_edit_last', '1'),
(399, 124, '_edit_lock', '1464556739:1'),
(401, 126, '_edit_last', '1'),
(402, 126, '_edit_lock', '1464556700:1'),
(404, 128, '_edit_last', '1'),
(405, 128, '_edit_lock', '1464387111:1'),
(407, 130, '_edit_last', '1'),
(408, 130, '_edit_lock', '1464387051:1'),
(410, 132, '_edit_last', '1'),
(411, 132, '_edit_lock', '1464387165:1'),
(413, 134, '_edit_last', '1'),
(414, 134, '_edit_lock', '1464386994:1'),
(416, 136, '_edit_last', '1'),
(417, 136, '_edit_lock', '1464386971:1'),
(420, 139, '_edit_last', '1'),
(421, 139, '_edit_lock', '1464196351:1'),
(422, 140, '_edit_last', '1'),
(423, 140, '_edit_lock', '1464382480:1'),
(424, 140, 'cfs_fields', 'a:3:{i:0;a:8:{s:2:"id";s:1:"2";s:4:"name";s:12:"about_banner";s:5:"label";s:12:"About Banner";s:4:"type";s:4:"file";s:5:"notes";s:17:"About page banner";s:9:"parent_id";i:0;s:6:"weight";i:0;s:7:"options";a:2:{s:12:"return_value";s:3:"url";s:8:"required";s:1:"0";}}i:1;a:8:{s:2:"id";s:1:"3";s:4:"name";s:9:"our_story";s:5:"label";s:9:"Our Story";s:4:"type";s:7:"wysiwyg";s:5:"notes";s:33:"This is the section for our story";s:9:"parent_id";i:0;s:6:"weight";i:1;s:7:"options";a:2:{s:10:"formatting";s:7:"default";s:8:"required";s:1:"0";}}i:2;a:8:{s:2:"id";s:1:"4";s:4:"name";s:8:"our_team";s:5:"label";s:8:"Our Team";s:4:"type";s:7:"wysiwyg";s:5:"notes";s:32:"This is the section for our team";s:9:"parent_id";i:0;s:6:"weight";i:2;s:7:"options";a:2:{s:10:"formatting";s:7:"default";s:8:"required";s:1:"0";}}}'),
(425, 140, 'cfs_rules', 'a:1:{s:14:"page_templates";a:2:{s:8:"operator";s:2:"==";s:6:"values";a:1:{i:0;s:9:"about.php";}}}'),
(426, 140, 'cfs_extras', 'a:3:{s:5:"order";s:1:"0";s:7:"context";s:6:"normal";s:11:"hide_editor";s:1:"0";}'),
(427, 10, '_wp_page_template', 'about.php'),
(428, 141, '_wp_attached_file', '2016/05/about-hero.jpg'),
(429, 141, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:4000;s:6:"height";i:2667;s:4:"file";s:22:"2016/05/about-hero.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"about-hero-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"about-hero-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"about-hero-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"about-hero-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(434, 139, '_wp_trash_meta_status', 'draft'),
(435, 139, '_wp_trash_meta_time', '1464197152'),
(436, 139, '_wp_desired_post_slug', ''),
(446, 10, 'about_banner', '141'),
(447, 10, 'our_story', '<p>Inhabitent Camping Supply Co. has been Vancouver baked-good icon for more than two whole months! Customers often comment on the bustle of activity they see in store…that’s where the magic happens every day.</p><p>We want to bridge the gap between the comfort of city life and the lovely Instagram-worthiness of the great outdoors that surround us. We sell gear that’s fun and functional. So much fun, in fact, that you’ll want to pitch a tent inside your one-bedroom apartment so you can use it everyday.</p>'),
(448, 10, 'our_team', '<p>Inhabitent Camping Supply Co.’s staff is made up of an amazing team of inspired retail associates. We really know our stuff when it comes to travel hammocks and campfire cooking gadgets. From a provincial park campground to the back-country, our staff knows what you need to outfit your outdoor outing.</p><p>Our shop in nestled away in a lovely little corner of Vancouver. Pop in, say hi, and try out our tents!</p>'),
(450, 136, '_thumbnail_id', '75'),
(453, 136, 'price', '$40.00'),
(454, 136, '_wp_old_slug', 'wood-axx'),
(455, 134, '_thumbnail_id', '74'),
(456, 134, 'price', '$400.00'),
(457, 132, '_thumbnail_id', '73'),
(459, 132, 'price', '$75.00'),
(460, 130, '_thumbnail_id', '72'),
(461, 130, 'price', '$22.00'),
(462, 128, '_thumbnail_id', '71'),
(463, 128, 'price', '$100.00'),
(464, 126, '_thumbnail_id', '70'),
(465, 126, 'price', '$220.00') ;
INSERT INTO `qwenjt_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(466, 124, '_thumbnail_id', '69'),
(467, 124, 'price', '$60.00'),
(468, 122, '_thumbnail_id', '68'),
(469, 122, 'price', '$42.00'),
(470, 120, '_thumbnail_id', '67'),
(472, 120, 'price', '$135.00'),
(476, 118, '_thumbnail_id', '66'),
(477, 118, 'price', '$28.00'),
(478, 116, '_thumbnail_id', '65'),
(479, 116, 'price', '$120.00'),
(480, 114, '_thumbnail_id', '64'),
(481, 114, 'price', '$45.00'),
(482, 112, '_thumbnail_id', '63'),
(483, 112, 'price', '$150.00'),
(484, 110, '_thumbnail_id', '62'),
(486, 108, '_thumbnail_id', '55'),
(487, 108, 'price', '$2500.00'),
(488, 106, '_thumbnail_id', '52'),
(489, 106, 'price', '$155.00'),
(490, 110, 'price', '$19.00') ;

#
# End of data contents of table `qwenjt_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `qwenjt_posts`
#

DROP TABLE IF EXISTS `qwenjt_posts`;


#
# Table structure of table `qwenjt_posts`
#

CREATE TABLE `qwenjt_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=149 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `qwenjt_posts`
#
INSERT INTO `qwenjt_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2016-05-18 22:54:52', '2016-05-18 22:54:52', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world__trashed', '', '', '2016-05-19 14:21:19', '2016-05-19 21:21:19', '', 0, 'http://localhost/student/?p=1', 0, 'post', '', 1),
(4, 1, '2016-05-18 16:00:26', '2016-05-18 23:00:26', '<p>Your Name (required)<br />\n    [text* your-name] </p>\n\n<p>Your Email (required)<br />\n    [email* your-email] </p>\n\n<p>Subject<br />\n    [text your-subject] </p>\n\n<p>Your Message<br />\n    [textarea your-message] </p>\n\n<p>[submit "Send"]</p>\nwpday1 "[your-subject]"\n[your-name] <tylerlforbes@gmail.com>\nFrom: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n--\nThis e-mail was sent from a contact form on wpday1 (http://localhost/student)\ntylerlforbes@gmail.com\nReply-To: [your-email]\n\n0\n0\n\nwpday1 "[your-subject]"\nwpday1 <tylerlforbes@gmail.com>\nMessage Body:\n[your-message]\n\n--\nThis e-mail was sent from a contact form on wpday1 (http://localhost/student)\n[your-email]\nReply-To: tylerlforbes@gmail.com\n\n0\n0\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nThe field is required.\nThe field is too long.\nThe field is too short.', 'Contact form 1', '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', '2016-05-18 16:00:26', '2016-05-18 23:00:26', '', 0, 'http://localhost/student/?post_type=wpcf7_contact_form&p=4', 0, 'wpcf7_contact_form', '', 0),
(8, 1, '2016-05-19 14:15:47', '2016-05-19 21:15:47', '', '404 page', '', 'trash', 'closed', 'closed', '', '404-page__trashed', '', '', '2016-05-24 15:07:14', '2016-05-24 22:07:14', '', 0, 'http://localhost/student/?page_id=8', 0, 'page', '', 0),
(9, 1, '2016-05-19 14:15:47', '2016-05-19 21:15:47', '', '404 page', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2016-05-19 14:15:47', '2016-05-19 21:15:47', '', 8, 'http://localhost/student/2016/05/19/8-revision-v1/', 0, 'revision', '', 0),
(10, 1, '2016-05-19 14:16:42', '2016-05-19 21:16:42', '&nbsp;\r\n\r\n&nbsp;\r\n<h2></h2>', 'About', '', 'publish', 'closed', 'closed', '', 'about-page', '', '', '2016-05-27 13:57:33', '2016-05-27 20:57:33', '', 0, 'http://localhost/student/?page_id=10', 0, 'page', '', 0),
(11, 1, '2016-05-19 14:16:42', '2016-05-19 21:16:42', '', 'About Page', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2016-05-19 14:16:42', '2016-05-19 21:16:42', '', 10, 'http://localhost/student/2016/05/19/10-revision-v1/', 0, 'revision', '', 0),
(12, 1, '2016-05-19 14:17:06', '2016-05-19 21:17:06', '', 'Adventures Archive Page', '', 'trash', 'closed', 'closed', '', 'adventures-archive-page__trashed', '', '', '2016-05-24 15:07:28', '2016-05-24 22:07:28', '', 0, 'http://localhost/student/?page_id=12', 0, 'page', '', 0),
(13, 1, '2016-05-19 14:17:06', '2016-05-19 21:17:06', '', 'Adventures Archive Page', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2016-05-19 14:17:06', '2016-05-19 21:17:06', '', 12, 'http://localhost/student/2016/05/19/12-revision-v1/', 0, 'revision', '', 0),
(14, 1, '2016-05-19 14:17:30', '2016-05-19 21:17:30', '', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact-page', '', '', '2016-05-24 15:40:52', '2016-05-24 22:40:52', '', 0, 'http://localhost/student/?page_id=14', 0, 'page', '', 0),
(15, 1, '2016-05-19 14:17:30', '2016-05-19 21:17:30', '', 'Contact Page', '', 'inherit', 'closed', 'closed', '', '14-revision-v1', '', '', '2016-05-19 14:17:30', '2016-05-19 21:17:30', '', 14, 'http://localhost/student/2016/05/19/14-revision-v1/', 0, 'revision', '', 0),
(16, 1, '2016-05-19 14:17:50', '2016-05-19 21:17:50', '', 'Homepage', '', 'publish', 'closed', 'closed', '', 'homepage', '', '', '2016-05-19 14:17:50', '2016-05-19 21:17:50', '', 0, 'http://localhost/student/?page_id=16', 0, 'page', '', 0),
(17, 1, '2016-05-19 14:17:50', '2016-05-19 21:17:50', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2016-05-19 14:17:50', '2016-05-19 21:17:50', '', 16, 'http://localhost/student/2016/05/19/16-revision-v1/', 0, 'revision', '', 0),
(18, 1, '2016-05-19 14:18:07', '2016-05-19 21:18:07', '', 'Journal', '', 'publish', 'closed', 'closed', '', 'journal-posts-page', '', '', '2016-05-24 15:39:29', '2016-05-24 22:39:29', '', 0, 'http://localhost/student/?page_id=18', 0, 'page', '', 0),
(19, 1, '2016-05-19 14:18:07', '2016-05-19 21:18:07', '', 'Journal Posts Page', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2016-05-19 14:18:07', '2016-05-19 21:18:07', '', 18, 'http://localhost/student/2016/05/19/18-revision-v1/', 0, 'revision', '', 0),
(20, 1, '2016-05-19 14:18:28', '2016-05-19 21:18:28', '', 'Product Type Archive Page', '', 'trash', 'closed', 'closed', '', 'product-type-archive-page__trashed', '', '', '2016-05-24 15:07:14', '2016-05-24 22:07:14', '', 0, 'http://localhost/student/?page_id=20', 0, 'page', '', 0),
(21, 1, '2016-05-19 14:18:28', '2016-05-19 21:18:28', '', 'Product Type Archive Page', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2016-05-19 14:18:28', '2016-05-19 21:18:28', '', 20, 'http://localhost/student/2016/05/19/20-revision-v1/', 0, 'revision', '', 0),
(22, 1, '2016-05-19 14:18:51', '2016-05-19 21:18:51', '', 'Search Results Page', '', 'publish', 'closed', 'closed', '', 'search-results-page', '', '', '2016-05-19 14:18:51', '2016-05-19 21:18:51', '', 0, 'http://localhost/student/?page_id=22', 0, 'page', '', 0),
(23, 1, '2016-05-19 14:18:51', '2016-05-19 21:18:51', '', 'Search Results Page', '', 'inherit', 'closed', 'closed', '', '22-revision-v1', '', '', '2016-05-19 14:18:51', '2016-05-19 21:18:51', '', 22, 'http://localhost/student/2016/05/19/22-revision-v1/', 0, 'revision', '', 0),
(24, 1, '2016-05-19 14:19:17', '2016-05-19 21:19:17', '', 'Single Adventure Post', '', 'trash', 'closed', 'closed', '', 'single-adventure-post__trashed', '', '', '2016-05-24 15:07:14', '2016-05-24 22:07:14', '', 0, 'http://localhost/student/?page_id=24', 0, 'page', '', 0),
(25, 1, '2016-05-19 14:19:17', '2016-05-19 21:19:17', '', 'Single Adventure Post', '', 'inherit', 'closed', 'closed', '', '24-revision-v1', '', '', '2016-05-19 14:19:17', '2016-05-19 21:19:17', '', 24, 'http://localhost/student/2016/05/19/24-revision-v1/', 0, 'revision', '', 0),
(26, 1, '2016-05-19 14:19:39', '2016-05-19 21:19:39', '', 'Single Journal', '', 'trash', 'closed', 'closed', '', 'single-journal__trashed', '', '', '2016-05-24 15:07:15', '2016-05-24 22:07:15', '', 0, 'http://localhost/student/?page_id=26', 0, 'page', '', 0),
(27, 1, '2016-05-19 14:19:39', '2016-05-19 21:19:39', '', 'Single Journal', '', 'inherit', 'closed', 'closed', '', '26-revision-v1', '', '', '2016-05-19 14:19:39', '2016-05-19 21:19:39', '', 26, 'http://localhost/student/2016/05/19/26-revision-v1/', 0, 'revision', '', 0),
(28, 1, '2016-05-19 14:19:57', '2016-05-19 21:19:57', '', 'Single Product', '', 'trash', 'closed', 'closed', '', 'single-product__trashed', '', '', '2016-05-24 15:07:15', '2016-05-24 22:07:15', '', 0, 'http://localhost/student/?page_id=28', 0, 'page', '', 0),
(29, 1, '2016-05-19 14:19:57', '2016-05-19 21:19:57', '', 'Single Product', '', 'inherit', 'closed', 'closed', '', '28-revision-v1', '', '', '2016-05-19 14:19:57', '2016-05-19 21:19:57', '', 28, 'http://localhost/student/2016/05/19/28-revision-v1/', 0, 'revision', '', 0),
(30, 1, '2016-05-19 14:21:19', '2016-05-19 21:21:19', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2016-05-19 14:21:19', '2016-05-19 21:21:19', '', 1, 'http://localhost/student/2016/05/19/1-revision-v1/', 0, 'revision', '', 0),
(32, 1, '2016-04-14 14:23:49', '2016-04-14 21:23:49', '<p class="BodyA" style="line-height: 120%;">Ethical tumblr gentrify listicle roof party. Normcore jean shorts single-origin coffee aesthetic, selvage williamsburg chartreuse austin banjo tumblr trust fund. Vinyl freegan trust fund, blue bottle chicharrones VHS fanny pack pop-up tumblr put a bird on it blog whatever. Authentic next level shabby chic squid. Brooklyn chicharrones fanny pack waistcoat deep v. Distillery cronut man bun, readymade gluten-free fap listicle bespoke meh cray yuccie vinyl sartorial kogi. Pickled retro organic kale chips.</p>\r\n<p class="BodyA" style="line-height: 120%;">Shabby chic bicycle rights vinyl, ugh ennui wayfarers four dollar toast. Leggings beard ennui, bushwick mixtape next level meditation master cleanse bicycle rights single-origin coffee post-ironic kogi butcher. Cold-pressed yuccie knausgaard truffaut, messenger bag blog plaid seitan pork belly chambray echo park. PBR&amp;B direct trade lomo actually quinoa. Marfa you probably haven’t heard of them fanny pack, everyday carry craft beer ethical before they sold out bespoke pabst truffaut chicharrones pitchfork synth echo park biodiesel. Kinfolk disrupt four loko plaid, tumblr cold-pressed YOLO microdosing art party stumptown hammock. Fap man braid polaroid pug.</p>', 'Van Camping Photo Contest', '', 'publish', 'open', 'open', '', 'van-camping-photo-contest', '', '', '2016-06-01 10:39:52', '2016-06-01 17:39:52', '', 0, 'http://localhost/student/?p=32', 0, 'post', '', 0),
(33, 1, '2016-05-19 14:25:25', '2016-05-19 21:25:25', '<p class="BodyA" style="line-height: 120%;">Ethical tumblr gentrify listicle roof party. Normcore jean shorts single-origin coffee aesthetic, selvage williamsburg chartreuse austin banjo tumblr trust fund. Vinyl freegan trust fund, blue bottle chicharrones VHS fanny pack pop-up tumblr put a bird on it blog whatever. Authentic next level shabby chic squid. Brooklyn chicharrones fanny pack waistcoat deep v. Distillery cronut man bun, readymade gluten-free fap listicle bespoke meh cray yuccie vinyl sartorial kogi. Pickled retro organic kale chips.</p>\r\n<p class="BodyA" style="line-height: 120%;"></p>\r\n<p class="BodyA" style="line-height: 120%;">Shabby chic bicycle rights vinyl, ugh ennui wayfarers four dollar toast. Leggings beard ennui, bushwick mixtape next level meditation master cleanse bicycle rights single-origin coffee post-ironic kogi butcher. Cold-pressed yuccie knausgaard truffaut, messenger bag blog plaid seitan pork belly chambray echo park. PBR&amp;B direct trade lomo actually quinoa. Marfa you probably haven’t heard of them fanny pack, everyday carry craft beer ethical before they sold out bespoke pabst truffaut chicharrones pitchfork synth echo park biodiesel. Kinfolk disrupt four loko plaid, tumblr cold-pressed YOLO microdosing art party stumptown hammock. Fap man braid polaroid pug.</p>', 'Van Camping Photo Contest', '', 'inherit', 'closed', 'closed', '', '32-revision-v1', '', '', '2016-05-19 14:25:25', '2016-05-19 21:25:25', '', 32, 'http://localhost/student/2016/05/19/32-revision-v1/', 0, 'revision', '', 0),
(34, 1, '2016-05-19 14:26:14', '2016-05-19 21:26:14', '<p class="BodyA" style="line-height: 120%;">Ethical tumblr gentrify listicle roof party. Normcore jean shorts single-origin coffee aesthetic, selvage williamsburg chartreuse austin banjo tumblr trust fund. Vinyl freegan trust fund, blue bottle chicharrones VHS fanny pack pop-up tumblr put a bird on it blog whatever. Authentic next level shabby chic squid. Brooklyn chicharrones fanny pack waistcoat deep v. Distillery cronut man bun, readymade gluten-free fap listicle bespoke meh cray yuccie vinyl sartorial kogi. Pickled retro organic kale chips.</p>\r\n<p class="BodyA" style="line-height: 120%;">Shabby chic bicycle rights vinyl, ugh ennui wayfarers four dollar toast. Leggings beard ennui, bushwick mixtape next level meditation master cleanse bicycle rights single-origin coffee post-ironic kogi butcher. Cold-pressed yuccie knausgaard truffaut, messenger bag blog plaid seitan pork belly chambray echo park. PBR&amp;B direct trade lomo actually quinoa. Marfa you probably haven’t heard of them fanny pack, everyday carry craft beer ethical before they sold out bespoke pabst truffaut chicharrones pitchfork synth echo park biodiesel. Kinfolk disrupt four loko plaid, tumblr cold-pressed YOLO microdosing art party stumptown hammock. Fap man braid polaroid pug.</p>', 'Van Camping Photo Contest', '', 'inherit', 'closed', 'closed', '', '32-revision-v1', '', '', '2016-05-19 14:26:14', '2016-05-19 21:26:14', '', 32, 'http://localhost/student/2016/05/19/32-revision-v1/', 0, 'revision', '', 0),
(35, 1, '2016-04-02 14:30:26', '2016-04-02 21:30:26', '<p class="BodyA" style="line-height: 120%;">Try-hard listicle truffaut locavore, pabst humblebrag bespoke flexitarian squid street art chia chicharrones. Gastropub portland cornhole poutine 90’s drinking vinegar, semiotics raw denim. Helvetica cornhole health goth pickled, portland banjo knausgaard drinking vinegar DIY YOLO trust fund tumblr skateboard church-key slow-carb. Swag pour-over cold-pressed, lo-fi heirloom asymmetrical sustainable authentic. Irony helvetica forage, mlkshk single-origin coffee scenester banjo jean shorts echo park hoodie ennui raw denim bitters tattooed plaid. Paleo quinoa mustache echo park, shoreditch scenester bitters chia shabby chic man braid tofu. Portland man bun scenester, wolf master cleanse iPhone selfies readymade godard sustainable asymmetrical williamsburg.</p>\r\n<p class="BodyA" style="line-height: 120%;">Health goth ramps cold-pressed, literally etsy lomo fashion axe brunch dreamcatcher mlkshk vegan. Dreamcatcher squid shoreditch, kogi cold-pressed paleo four loko DIY umami keffiyeh. Blog green juice tofu yr chillwave taxidermy. Kinfolk aesthetic asymmetrical, waistcoat cray fashion axe keytar pork belly truffaut narwhal post-ironic squid listicle poutine. Twee quinoa brooklyn pour-over, beard wayfarers flannel. Shoreditch meditation ramps, tofu keytar etsy plaid bespoke. Yr synth poutine, farm-to-table raw denim mixtape everyday carry brunch scenester.</p>', 'Fireside Libations: 3 Warm Cocktail Recipes', '', 'publish', 'open', 'open', '', 'fireside-libations-3-warm-cocktail-recipes', '', '', '2016-05-19 14:33:09', '2016-05-19 21:33:09', '', 0, 'http://localhost/student/?p=35', 0, 'post', '', 0),
(36, 1, '2016-05-19 14:32:28', '2016-05-19 21:32:28', '<p class="BodyA" style="line-height: 120%;">Try-hard listicle truffaut locavore, pabst humblebrag bespoke flexitarian squid street art chia chicharrones. Gastropub portland cornhole poutine 90’s drinking vinegar, semiotics raw denim. Helvetica cornhole health goth pickled, portland banjo knausgaard drinking vinegar DIY YOLO trust fund tumblr skateboard church-key slow-carb. Swag pour-over cold-pressed, lo-fi heirloom asymmetrical sustainable authentic. Irony helvetica forage, mlkshk single-origin coffee scenester banjo jean shorts echo park hoodie ennui raw denim bitters tattooed plaid. Paleo quinoa mustache echo park, shoreditch scenester bitters chia shabby chic man braid tofu. Portland man bun scenester, wolf master cleanse iPhone selfies readymade godard sustainable asymmetrical williamsburg.</p>', 'Fireside Libations: 3 Warm Cocktail Recipes', '', 'inherit', 'closed', 'closed', '', '35-revision-v1', '', '', '2016-05-19 14:32:28', '2016-05-19 21:32:28', '', 35, 'http://localhost/student/2016/05/19/35-revision-v1/', 0, 'revision', '', 0),
(38, 1, '2016-05-19 14:33:09', '2016-05-19 21:33:09', '<p class="BodyA" style="line-height: 120%;">Try-hard listicle truffaut locavore, pabst humblebrag bespoke flexitarian squid street art chia chicharrones. Gastropub portland cornhole poutine 90’s drinking vinegar, semiotics raw denim. Helvetica cornhole health goth pickled, portland banjo knausgaard drinking vinegar DIY YOLO trust fund tumblr skateboard church-key slow-carb. Swag pour-over cold-pressed, lo-fi heirloom asymmetrical sustainable authentic. Irony helvetica forage, mlkshk single-origin coffee scenester banjo jean shorts echo park hoodie ennui raw denim bitters tattooed plaid. Paleo quinoa mustache echo park, shoreditch scenester bitters chia shabby chic man braid tofu. Portland man bun scenester, wolf master cleanse iPhone selfies readymade godard sustainable asymmetrical williamsburg.</p>\r\n<p class="BodyA" style="line-height: 120%;">Health goth ramps cold-pressed, literally etsy lomo fashion axe brunch dreamcatcher mlkshk vegan. Dreamcatcher squid shoreditch, kogi cold-pressed paleo four loko DIY umami keffiyeh. Blog green juice tofu yr chillwave taxidermy. Kinfolk aesthetic asymmetrical, waistcoat cray fashion axe keytar pork belly truffaut narwhal post-ironic squid listicle poutine. Twee quinoa brooklyn pour-over, beard wayfarers flannel. Shoreditch meditation ramps, tofu keytar etsy plaid bespoke. Yr synth poutine, farm-to-table raw denim mixtape everyday carry brunch scenester.</p>', 'Fireside Libations: 3 Warm Cocktail Recipes', '', 'inherit', 'closed', 'closed', '', '35-revision-v1', '', '', '2016-05-19 14:33:09', '2016-05-19 21:33:09', '', 35, 'http://localhost/student/2016/05/19/35-revision-v1/', 0, 'revision', '', 0),
(39, 1, '2016-03-31 14:33:15', '2016-03-31 21:33:15', '&nbsp;\r\n\r\n&nbsp;\r\n\r\nPaleo semiotics gastropub messenger bag, kogi beard tattooed truffaut cred artisan. Skateboard cliche selfies fashion axe, viral ugh vinyl plaid before they sold out squid jean shorts tofu letterpress. Kombucha gluten-free banh mi authentic paleo, kale chips typewriter kogi normcore mustache cliche before they sold out intelligentsia poutine 90’s. Fixie mlkshk put a bird on it messenger bag cardigan, gochujang cronut health goth tousled truffaut humblebrag keytar you probably haven’t heard of them chillwave. Put a bird on it flexitarian cornhole leggings umami. Umami polaroid gentrify distillery tacos flannel green juice.\r\n\r\n&nbsp;\r\n\r\nTruffaut twee master cleanse, drinking vinegar poutine +1 letterpress fanny pack. Truffaut dreamcatcher church-key 90’s bicycle rights. Actually tumblr fingerstache schlitz trust fund keffiyeh. Gastropub pitchfork jean shorts paleo, photo booth 90’s yr drinking vinegar shoreditch vice iPhone 3 wolf moon neutra craft beer taxidermy. Cronut YOLO readymade man bun, trust fund kale chips meggings four loko chia blue bottle raw denim wayfarers beard. Authentic freegan waistcoat hoodie. Hashtag dreamcatcher pickled, locavore messenger bag banh mi tousled man braid ennui.', 'How To: Eating Healthy Meals in the Wild', '', 'publish', 'open', 'open', '', 'how-to-eating-healthy-meals-in-the-wild', '', '', '2016-05-19 14:34:17', '2016-05-19 21:34:17', '', 0, 'http://localhost/student/?p=39', 0, 'post', '', 0),
(40, 1, '2016-05-19 14:34:17', '2016-05-19 21:34:17', '&nbsp;\r\n\r\n&nbsp;\r\n\r\nPaleo semiotics gastropub messenger bag, kogi beard tattooed truffaut cred artisan. Skateboard cliche selfies fashion axe, viral ugh vinyl plaid before they sold out squid jean shorts tofu letterpress. Kombucha gluten-free banh mi authentic paleo, kale chips typewriter kogi normcore mustache cliche before they sold out intelligentsia poutine 90’s. Fixie mlkshk put a bird on it messenger bag cardigan, gochujang cronut health goth tousled truffaut humblebrag keytar you probably haven’t heard of them chillwave. Put a bird on it flexitarian cornhole leggings umami. Umami polaroid gentrify distillery tacos flannel green juice.\r\n\r\n&nbsp;\r\n\r\nTruffaut twee master cleanse, drinking vinegar poutine +1 letterpress fanny pack. Truffaut dreamcatcher church-key 90’s bicycle rights. Actually tumblr fingerstache schlitz trust fund keffiyeh. Gastropub pitchfork jean shorts paleo, photo booth 90’s yr drinking vinegar shoreditch vice iPhone 3 wolf moon neutra craft beer taxidermy. Cronut YOLO readymade man bun, trust fund kale chips meggings four loko chia blue bottle raw denim wayfarers beard. Authentic freegan waistcoat hoodie. Hashtag dreamcatcher pickled, locavore messenger bag banh mi tousled man braid ennui.', 'How To: Eating Healthy Meals in the Wild', '', 'inherit', 'closed', 'closed', '', '39-revision-v1', '', '', '2016-05-19 14:34:17', '2016-05-19 21:34:17', '', 39, 'http://localhost/student/2016/05/19/39-revision-v1/', 0, 'revision', '', 0),
(41, 1, '2016-03-19 14:34:29', '2016-03-19 21:34:29', 'Wayfarers VHS chambray schlitz, ramps semiotics post-ironic franzen fixie wolf polaroid viral. Blue bottle scenester paleo bitters, master cleanse put a bird on it PBR&amp;B brunch kinfolk echo park pitchfork YOLO. Forage biodiesel polaroid beard, scenester normcore actually swag food truck meggings. Readymade cornhole pabst gastropub. Roof party put a bird on it quinoa, bicycle rights kickstarter venmo master cleanse. Sustainable keffiyeh leggings, farm-to-table cliche banh mi drinking vinegar. Crucifix tote bag pork belly, before they sold out artisan YOLO listicle kombucha gluten-free vice shoreditch actually swag direct trade.\r\n\r\n&nbsp;\r\n\r\nVenmo XOXO meh hella raw denim. Migas listicle photo booth, wayfarers single-origin coffee artisan gastropub iPhone echo park. Banjo forage kale chips tilde semiotics echo park artisan art party, meditation viral retro pitchfork. Seitan tacos cray waistcoat, migas pickled fap try-hard gentrify narwhal pinterest thundercats keffiyeh. Keffiyeh hashtag tofu slow-carb, yr pork belly VHS normcore typewriter gastropub letterpress echo park. Ugh sriracha messenger bag umami, mixtape vice flexitarian forage iPhone synth sustainable banjo. Banh mi humblebrag shoreditch, single-origin coffee butcher skateboard farm-to-table bicycle rights.', '5 Tips for Solo Camping', '', 'publish', 'open', 'open', '', '5-tips-for-solo-camping', '', '', '2016-05-19 14:36:01', '2016-05-19 21:36:01', '', 0, 'http://localhost/student/?p=41', 0, 'post', '', 0),
(42, 1, '2016-05-19 14:35:20', '2016-05-19 21:35:20', '&nbsp;\r\n\r\n<strong>Published on:</strong> March 19, 2016\r\n\r\n<strong>Categories:</strong> How-tos\r\n\r\n<strong>Tags:</strong> Tenting\r\n\r\n&nbsp;\r\n\r\nWayfarers VHS chambray schlitz, ramps semiotics post-ironic franzen fixie wolf polaroid viral. Blue bottle scenester paleo bitters, master cleanse put a bird on it PBR&amp;B brunch kinfolk echo park pitchfork YOLO. Forage biodiesel polaroid beard, scenester normcore actually swag food truck meggings. Readymade cornhole pabst gastropub. Roof party put a bird on it quinoa, bicycle rights kickstarter venmo master cleanse. Sustainable keffiyeh leggings, farm-to-table cliche banh mi drinking vinegar. Crucifix tote bag pork belly, before they sold out artisan YOLO listicle kombucha gluten-free vice shoreditch actually swag direct trade.\r\n\r\n&nbsp;\r\n\r\nVenmo XOXO meh hella raw denim. Migas listicle photo booth, wayfarers single-origin coffee artisan gastropub iPhone echo park. Banjo forage kale chips tilde semiotics echo park artisan art party, meditation viral retro pitchfork. Seitan tacos cray waistcoat, migas pickled fap try-hard gentrify narwhal pinterest thundercats keffiyeh. Keffiyeh hashtag tofu slow-carb, yr pork belly VHS normcore typewriter gastropub letterpress echo park. Ugh sriracha messenger bag umami, mixtape vice flexitarian forage iPhone synth sustainable banjo. Banh mi humblebrag shoreditch, single-origin coffee butcher skateboard farm-to-table bicycle rights.', '5 Tips for Solo Camping', '', 'inherit', 'closed', 'closed', '', '41-revision-v1', '', '', '2016-05-19 14:35:20', '2016-05-19 21:35:20', '', 41, 'http://localhost/student/2016/05/19/41-revision-v1/', 0, 'revision', '', 0),
(44, 1, '2016-05-19 14:36:01', '2016-05-19 21:36:01', 'Wayfarers VHS chambray schlitz, ramps semiotics post-ironic franzen fixie wolf polaroid viral. Blue bottle scenester paleo bitters, master cleanse put a bird on it PBR&amp;B brunch kinfolk echo park pitchfork YOLO. Forage biodiesel polaroid beard, scenester normcore actually swag food truck meggings. Readymade cornhole pabst gastropub. Roof party put a bird on it quinoa, bicycle rights kickstarter venmo master cleanse. Sustainable keffiyeh leggings, farm-to-table cliche banh mi drinking vinegar. Crucifix tote bag pork belly, before they sold out artisan YOLO listicle kombucha gluten-free vice shoreditch actually swag direct trade.\r\n\r\n&nbsp;\r\n\r\nVenmo XOXO meh hella raw denim. Migas listicle photo booth, wayfarers single-origin coffee artisan gastropub iPhone echo park. Banjo forage kale chips tilde semiotics echo park artisan art party, meditation viral retro pitchfork. Seitan tacos cray waistcoat, migas pickled fap try-hard gentrify narwhal pinterest thundercats keffiyeh. Keffiyeh hashtag tofu slow-carb, yr pork belly VHS normcore typewriter gastropub letterpress echo park. Ugh sriracha messenger bag umami, mixtape vice flexitarian forage iPhone synth sustainable banjo. Banh mi humblebrag shoreditch, single-origin coffee butcher skateboard farm-to-table bicycle rights.', '5 Tips for Solo Camping', '', 'inherit', 'closed', 'closed', '', '41-revision-v1', '', '', '2016-05-19 14:36:01', '2016-05-19 21:36:01', '', 41, 'http://localhost/student/2016/05/19/41-revision-v1/', 0, 'revision', '', 0),
(45, 1, '2016-03-10 14:36:09', '2016-03-10 22:36:09', '&nbsp;\r\n\r\n&nbsp;\r\n\r\nFashion axe schlitz selvage, art party fixie ugh skateboard fap keffiyeh intelligentsia gastropub tattooed humblebrag brunch shabby chic. Tilde selvage ennui, ethical sartorial keytar gastropub mlkshk. Migas seitan lumbersexual, paleo kogi sriracha photo booth hoodie franzen. XOXO fap master cleanse everyday carry, four loko helvetica marfa. Tousled health goth normcore, raw denim banh mi bespoke quinoa. Readymade keytar iPhone fashion axe, raw denim put a bird on it 3 wolf moon plaid fap you probably haven’t heard of them gentrify tumblr kickstarter seitan. Stumptown cold-pressed green juice, vinyl roof party mixtape gluten-free fashion axe kickstarter kitsch.\r\n\r\n&nbsp;\r\n\r\nKogi mixtape tousled chicharrones art party kinfolk. Synth vinyl tote bag food truck mumblecore roof party, fashion axe heirloom wolf twee butcher marfa gentrify keytar neutra. Scenester cardigan twee, gochujang butcher ugh blog before they sold out chambray sriracha cold-pressed fanny pack kitsch jean shorts. Master cleanse man bun flannel, locavore lo-fi hashtag next level wolf thundercats cronut man braid helvetica jean shorts listicle. XOXO kogi health goth, jean shorts scenester pug waistcoat shabby chic fap polaroid church-key organic brunch flexitarian. Yuccie lo-fi hammock VHS, waistcoat hashtag post-ironic gochujang helvetica paleo four loko kogi meh cray sartorial. Flexitarian paleo health goth freegan blue bottle.\r\n\r\n&nbsp;\r\n\r\nViral hashtag deep v, iPhone street art tacos helvetica semiotics sustainable man braid paleo affogato raw denim flexitarian mumblecore. Bicycle rights shabby chic humblebrag small batch pop-up. Slow-carb bespoke biodiesel sartorial migas fashion axe, mumblecore pop-up tumblr. Gentrify YOLO cray art party occupy, readymade wolf mustache. Food truck tacos microdosing poutine, kombucha YOLO mumblecore. Freegan typewriter distillery truffaut. Portland slow-carb hammock, yuccie cardigan before they sold out organic blog messenger bag tattooed church-key biodiesel XOXO tumblr.', 'Glamping Made Easy', '', 'publish', 'open', 'open', '', 'glamping-made-easy', '', '', '2016-05-19 14:37:41', '2016-05-19 21:37:41', '', 0, 'http://localhost/student/?p=45', 0, 'post', '', 0),
(46, 1, '2016-05-19 14:37:41', '2016-05-19 21:37:41', '&nbsp;\r\n\r\n&nbsp;\r\n\r\nFashion axe schlitz selvage, art party fixie ugh skateboard fap keffiyeh intelligentsia gastropub tattooed humblebrag brunch shabby chic. Tilde selvage ennui, ethical sartorial keytar gastropub mlkshk. Migas seitan lumbersexual, paleo kogi sriracha photo booth hoodie franzen. XOXO fap master cleanse everyday carry, four loko helvetica marfa. Tousled health goth normcore, raw denim banh mi bespoke quinoa. Readymade keytar iPhone fashion axe, raw denim put a bird on it 3 wolf moon plaid fap you probably haven’t heard of them gentrify tumblr kickstarter seitan. Stumptown cold-pressed green juice, vinyl roof party mixtape gluten-free fashion axe kickstarter kitsch.\r\n\r\n&nbsp;\r\n\r\nKogi mixtape tousled chicharrones art party kinfolk. Synth vinyl tote bag food truck mumblecore roof party, fashion axe heirloom wolf twee butcher marfa gentrify keytar neutra. Scenester cardigan twee, gochujang butcher ugh blog before they sold out chambray sriracha cold-pressed fanny pack kitsch jean shorts. Master cleanse man bun flannel, locavore lo-fi hashtag next level wolf thundercats cronut man braid helvetica jean shorts listicle. XOXO kogi health goth, jean shorts scenester pug waistcoat shabby chic fap polaroid church-key organic brunch flexitarian. Yuccie lo-fi hammock VHS, waistcoat hashtag post-ironic gochujang helvetica paleo four loko kogi meh cray sartorial. Flexitarian paleo health goth freegan blue bottle.\r\n\r\n&nbsp;\r\n\r\nViral hashtag deep v, iPhone street art tacos helvetica semiotics sustainable man braid paleo affogato raw denim flexitarian mumblecore. Bicycle rights shabby chic humblebrag small batch pop-up. Slow-carb bespoke biodiesel sartorial migas fashion axe, mumblecore pop-up tumblr. Gentrify YOLO cray art party occupy, readymade wolf mustache. Food truck tacos microdosing poutine, kombucha YOLO mumblecore. Freegan typewriter distillery truffaut. Portland slow-carb hammock, yuccie cardigan before they sold out organic blog messenger bag tattooed church-key biodiesel XOXO tumblr.', 'Glamping Made Easy', '', 'inherit', 'closed', 'closed', '', '45-revision-v1', '', '', '2016-05-19 14:37:41', '2016-05-19 21:37:41', '', 45, 'http://localhost/student/2016/05/19/45-revision-v1/', 0, 'revision', '', 0),
(47, 1, '2016-05-19 14:41:20', '2016-05-19 21:41:20', 'Our Story\r\n\r\n&nbsp;\r\n\r\nInhabitent Camping Supply Co. has been Vancouver baked-good icon for more than two whole months! Customers often comment on the bustle of activity they see in store…that’s where the magic happens every day.\r\n\r\n&nbsp;\r\n\r\nWe want to bridge the gap between the comfort of city life and the lovely Instagram-worthiness of the great outdoors that surround us. We sell gear that’s fun and functional. So much fun, in fact, that you’ll want to pitch a tent inside your one-bedroom apartment so you can use it everyday.\r\n\r\n&nbsp;\r\n<h2>Our Team</h2>\r\n&nbsp;\r\n\r\nInhabitent Camping Supply Co.’s staff is made up of an amazing team of inspired retail associates. We really know our stuff when it comes to travel hammocks and campfire cooking gadgets. From a provincial park campground to the back-country, our staff knows what you need to outfit your outdoor outing.\r\n\r\n&nbsp;\r\n\r\nOur shop in nestled away in a lovely little corner of Vancouver. Pop in, say hi, and try out our tents!', 'About', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2016-05-19 14:41:20', '2016-05-19 21:41:20', '', 10, 'http://localhost/student/2016/05/19/10-revision-v1/', 0, 'revision', '', 0),
(48, 1, '2016-05-19 15:03:10', '2016-05-19 22:03:10', '', 'beach-bonfire', '', 'inherit', 'open', 'closed', '', 'beach-bonfire', '', '', '2016-05-19 15:03:10', '2016-05-19 22:03:10', '', 0, 'http://localhost/student/wp-content/uploads/2016/05/beach-bonfire.jpg', 0, 'attachment', 'image/jpeg', 0),
(49, 1, '2016-05-19 15:03:13', '2016-05-19 22:03:13', '', 'canoe-girl', '', 'inherit', 'open', 'closed', '', 'canoe-girl', '', '', '2016-05-19 15:03:13', '2016-05-19 22:03:13', '', 0, 'http://localhost/student/wp-content/uploads/2016/05/canoe-girl.jpg', 0, 'attachment', 'image/jpeg', 0),
(50, 1, '2016-05-19 15:03:16', '2016-05-19 22:03:16', '', 'mountain-hikers', '', 'inherit', 'open', 'closed', '', 'mountain-hikers', '', '', '2016-05-19 15:03:16', '2016-05-19 22:03:16', '', 0, 'http://localhost/student/wp-content/uploads/2016/05/mountain-hikers.jpg', 0, 'attachment', 'image/jpeg', 0),
(51, 1, '2016-05-19 15:03:20', '2016-05-19 22:03:20', '', 'night-sky', '', 'inherit', 'open', 'closed', '', 'night-sky', '', '', '2016-05-19 15:03:20', '2016-05-19 22:03:20', '', 0, 'http://localhost/student/wp-content/uploads/2016/05/night-sky.jpg', 0, 'attachment', 'image/jpeg', 0),
(52, 1, '2016-05-19 15:03:23', '2016-05-19 22:03:23', '', 'glamping', '', 'inherit', 'open', 'closed', '', 'glamping', '', '', '2016-05-19 15:03:23', '2016-05-19 22:03:23', '', 0, 'http://localhost/student/wp-content/uploads/2016/05/glamping.jpg', 0, 'attachment', 'image/jpeg', 0),
(53, 1, '2016-05-19 15:03:26', '2016-05-19 22:03:26', '', 'healthy-camp-food', '', 'inherit', 'open', 'closed', '', 'healthy-camp-food', '', '', '2016-05-19 15:03:26', '2016-05-19 22:03:26', '', 0, 'http://localhost/student/wp-content/uploads/2016/05/healthy-camp-food.jpg', 0, 'attachment', 'image/jpeg', 0),
(54, 1, '2016-05-19 15:03:29', '2016-05-19 22:03:29', '', 'solo-camping', '', 'inherit', 'open', 'closed', '', 'solo-camping', '', '', '2016-05-19 15:03:29', '2016-05-19 22:03:29', '', 0, 'http://localhost/student/wp-content/uploads/2016/05/solo-camping.jpg', 0, 'attachment', 'image/jpeg', 0),
(55, 1, '2016-05-19 15:03:32', '2016-05-19 22:03:32', '', 'van-camper', '', 'inherit', 'open', 'closed', '', 'van-camper', '', '', '2016-05-19 15:03:32', '2016-05-19 22:03:32', '', 0, 'http://localhost/student/wp-content/uploads/2016/05/van-camper.jpg', 0, 'attachment', 'image/jpeg', 0),
(56, 1, '2016-05-19 15:03:35', '2016-05-19 22:03:35', '', 'warm-cocktail', '', 'inherit', 'open', 'closed', '', 'warm-cocktail', '', '', '2016-05-19 15:03:35', '2016-05-19 22:03:35', '', 0, 'http://localhost/student/wp-content/uploads/2016/05/warm-cocktail.jpg', 0, 'attachment', 'image/jpeg', 0),
(57, 1, '2016-05-19 15:03:39', '2016-05-19 22:03:39', '', 'dark-wood', '', 'inherit', 'open', 'closed', '', 'dark-wood', '', '', '2016-05-19 15:03:39', '2016-05-19 22:03:39', '', 0, 'http://localhost/student/wp-content/uploads/2016/05/dark-wood.png', 0, 'attachment', 'image/png', 0),
(58, 1, '2016-05-19 15:03:41', '2016-05-19 22:03:41', '', 'dark-wood@2x', '', 'inherit', 'open', 'closed', '', 'dark-wood2x', '', '', '2016-05-19 15:03:41', '2016-05-19 22:03:41', '', 0, 'http://localhost/student/wp-content/uploads/2016/05/dark-wood@2x.png', 0, 'attachment', 'image/png', 0),
(59, 1, '2016-05-19 15:03:45', '2016-05-19 22:03:45', '', 'home-hero', '', 'inherit', 'open', 'closed', '', 'home-hero', '', '', '2016-05-19 15:03:45', '2016-05-19 22:03:45', '', 0, 'http://localhost/student/wp-content/uploads/2016/05/home-hero.jpg', 0, 'attachment', 'image/jpeg', 0),
(60, 1, '2016-05-19 15:04:03', '2016-05-19 22:04:03', '', 'beach-tent', '', 'inherit', 'open', 'closed', '', 'beach-tent', '', '', '2016-05-19 15:04:03', '2016-05-19 22:04:03', '', 0, 'http://localhost/student/wp-content/uploads/2016/05/beach-tent.jpg', 0, 'attachment', 'image/jpeg', 0),
(61, 1, '2016-05-19 15:04:06', '2016-05-19 22:04:06', '', 'camper-van', '', 'inherit', 'open', 'closed', '', 'camper-van', '', '', '2016-05-19 15:04:06', '2016-05-19 22:04:06', '', 0, 'http://localhost/student/wp-content/uploads/2016/05/camper-van.jpg', 0, 'attachment', 'image/jpeg', 0),
(62, 1, '2016-05-19 15:04:09', '2016-05-19 22:04:09', '', 'ceramic-mugs', '', 'inherit', 'open', 'closed', '', 'ceramic-mugs', '', '', '2016-05-19 15:04:09', '2016-05-19 22:04:09', '', 0, 'http://localhost/student/wp-content/uploads/2016/05/ceramic-mugs.jpg', 0, 'attachment', 'image/jpeg', 0),
(63, 1, '2016-05-19 15:04:12', '2016-05-19 22:04:12', '', 'film-cameras', '', 'inherit', 'open', 'closed', '', 'film-cameras', '', '', '2016-05-19 15:04:12', '2016-05-19 22:04:12', '', 0, 'http://localhost/student/wp-content/uploads/2016/05/film-cameras.jpg', 0, 'attachment', 'image/jpeg', 0),
(64, 1, '2016-05-19 15:04:15', '2016-05-19 22:04:15', '', 'flannel-shirt', '', 'inherit', 'open', 'closed', '', 'flannel-shirt', '', '', '2016-05-19 15:04:15', '2016-05-19 22:04:15', '', 0, 'http://localhost/student/wp-content/uploads/2016/05/flannel-shirt.jpg', 0, 'attachment', 'image/jpeg', 0),
(65, 1, '2016-05-19 15:04:18', '2016-05-19 22:04:18', '', 'gas-stove', '', 'inherit', 'open', 'closed', '', 'gas-stove', '', '', '2016-05-19 15:04:18', '2016-05-19 22:04:18', '', 0, 'http://localhost/student/wp-content/uploads/2016/05/gas-stove.jpg', 0, 'attachment', 'image/jpeg', 0),
(66, 1, '2016-05-19 15:04:21', '2016-05-19 22:04:21', '', 'hand-knit-toque', '', 'inherit', 'open', 'closed', '', 'hand-knit-toque', '', '', '2016-05-19 15:04:21', '2016-05-19 22:04:21', '', 0, 'http://localhost/student/wp-content/uploads/2016/05/hand-knit-toque.jpg', 0, 'attachment', 'image/jpeg', 0),
(67, 1, '2016-05-19 15:04:24', '2016-05-19 22:04:24', '', 'hiking-boots', '', 'inherit', 'open', 'closed', '', 'hiking-boots', '', '', '2016-05-19 15:04:24', '2016-05-19 22:04:24', '', 0, 'http://localhost/student/wp-content/uploads/2016/05/hiking-boots.jpg', 0, 'attachment', 'image/jpeg', 0),
(68, 1, '2016-05-19 15:04:27', '2016-05-19 22:04:27', '', 'large-thermos', '', 'inherit', 'open', 'closed', '', 'large-thermos', '', '', '2016-05-19 15:04:27', '2016-05-19 22:04:27', '', 0, 'http://localhost/student/wp-content/uploads/2016/05/large-thermos.jpg', 0, 'attachment', 'image/jpeg', 0),
(69, 1, '2016-05-19 15:04:30', '2016-05-19 22:04:30', '', 'leather-satchel', '', 'inherit', 'open', 'closed', '', 'leather-satchel', '', '', '2016-05-19 15:04:30', '2016-05-19 22:04:30', '', 0, 'http://localhost/student/wp-content/uploads/2016/05/leather-satchel.jpg', 0, 'attachment', 'image/jpeg', 0),
(70, 1, '2016-05-19 15:04:33', '2016-05-19 22:04:33', '', 'nylon-tents', '', 'inherit', 'open', 'closed', '', 'nylon-tents', '', '', '2016-05-19 15:04:33', '2016-05-19 22:04:33', '', 0, 'http://localhost/student/wp-content/uploads/2016/05/nylon-tents.jpg', 0, 'attachment', 'image/jpeg', 0),
(71, 1, '2016-05-19 15:04:36', '2016-05-19 22:04:36', '', 'rustic-tools', '', 'inherit', 'open', 'closed', '', 'rustic-tools', '', '', '2016-05-19 15:04:36', '2016-05-19 22:04:36', '', 0, 'http://localhost/student/wp-content/uploads/2016/05/rustic-tools.jpg', 0, 'attachment', 'image/jpeg', 0),
(72, 1, '2016-05-19 15:04:41', '2016-05-19 22:04:41', '', 'stew-can', '', 'inherit', 'open', 'closed', '', 'stew-can', '', '', '2016-05-19 15:04:41', '2016-05-19 22:04:41', '', 0, 'http://localhost/student/wp-content/uploads/2016/05/stew-can.jpg', 0, 'attachment', 'image/jpeg', 0),
(73, 1, '2016-05-19 15:04:46', '2016-05-19 22:04:46', '', 'travel-hammock', '', 'inherit', 'open', 'closed', '', 'travel-hammock', '', '', '2016-05-19 15:04:46', '2016-05-19 22:04:46', '', 0, 'http://localhost/student/wp-content/uploads/2016/05/travel-hammock.jpg', 0, 'attachment', 'image/jpeg', 0),
(74, 1, '2016-05-19 15:04:49', '2016-05-19 22:04:49', '', 'weathered-canoes', '', 'inherit', 'open', 'closed', '', 'weathered-canoes', '', '', '2016-05-19 15:04:49', '2016-05-19 22:04:49', '', 0, 'http://localhost/student/wp-content/uploads/2016/05/weathered-canoes.jpg', 0, 'attachment', 'image/jpeg', 0),
(75, 1, '2016-05-19 15:04:53', '2016-05-19 22:04:53', '', 'wood-ax', '', 'inherit', 'open', 'closed', '', 'wood-ax', '', '', '2016-05-27 15:00:42', '2016-05-27 22:00:42', '', 136, 'http://localhost/student/wp-content/uploads/2016/05/wood-ax.jpg', 0, 'attachment', 'image/jpeg', 0),
(76, 1, '2016-05-24 13:31:38', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-05-24 13:31:38', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=76', 1, 'nav_menu_item', '', 0),
(77, 1, '2016-05-24 13:31:39', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-05-24 13:31:39', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=77', 1, 'nav_menu_item', '', 0),
(78, 1, '2016-05-24 13:31:40', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-05-24 13:31:40', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=78', 1, 'nav_menu_item', '', 0),
(79, 1, '2016-05-24 13:31:40', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-05-24 13:31:40', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=79', 1, 'nav_menu_item', '', 0),
(80, 1, '2016-05-24 13:31:41', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-05-24 13:31:41', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=80', 1, 'nav_menu_item', '', 0),
(81, 1, '2016-05-24 13:31:42', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-05-24 13:31:42', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=81', 1, 'nav_menu_item', '', 0),
(82, 1, '2016-05-24 13:31:42', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-05-24 13:31:42', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=82', 1, 'nav_menu_item', '', 0),
(83, 1, '2016-05-24 13:31:43', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-05-24 13:31:43', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=83', 1, 'nav_menu_item', '', 0),
(84, 1, '2016-05-24 13:31:43', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-05-24 13:31:43', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=84', 1, 'nav_menu_item', '', 0),
(85, 1, '2016-05-24 13:31:44', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-05-24 13:31:44', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=85', 1, 'nav_menu_item', '', 0),
(86, 1, '2016-05-24 13:31:44', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-05-24 13:31:44', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=86', 1, 'nav_menu_item', '', 0),
(87, 1, '2016-05-24 13:31:45', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-05-24 13:31:45', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=87', 1, 'nav_menu_item', '', 0),
(88, 1, '2016-05-24 14:05:07', '2016-05-24 21:05:07', 'This is my test product', 'Test Product', '', 'trash', 'closed', 'closed', '', 'test-product__trashed', '', '', '2016-05-24 15:54:40', '2016-05-24 22:54:40', '', 0, 'http://localhost/student/?post_type=product&#038;p=88', 0, 'product', '', 0),
(89, 1, '2016-05-24 14:05:07', '2016-05-24 21:05:07', 'This is my test product', 'Test Product', '', 'inherit', 'closed', 'closed', '', '88-revision-v1', '', '', '2016-05-24 14:05:07', '2016-05-24 21:05:07', '', 88, 'http://localhost/student/2016/05/24/88-revision-v1/', 0, 'revision', '', 0),
(90, 1, '2016-05-24 14:44:56', '2016-05-24 21:44:56', '', 'Product Field', '', 'publish', 'closed', 'closed', '', 'product-field', '', '', '2016-05-24 14:44:56', '2016-05-24 21:44:56', '', 0, 'http://localhost/student/?post_type=cfs&#038;p=90', 0, 'cfs', '', 0),
(91, 1, '2016-05-24 15:36:10', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-05-24 15:36:10', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=91', 1, 'nav_menu_item', '', 0),
(92, 1, '2016-05-24 15:36:11', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-05-24 15:36:11', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=92', 1, 'nav_menu_item', '', 0),
(93, 1, '2016-05-24 15:36:12', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-05-24 15:36:12', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=93', 1, 'nav_menu_item', '', 0),
(94, 1, '2016-05-24 15:36:13', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-05-24 15:36:13', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=94', 1, 'nav_menu_item', '', 0),
(95, 1, '2016-05-24 15:36:13', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-05-24 15:36:13', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=95', 1, 'nav_menu_item', '', 0),
(96, 1, '2016-05-24 15:36:14', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-05-24 15:36:14', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=96', 1, 'nav_menu_item', '', 0),
(98, 1, '2016-05-24 15:37:48', '2016-05-24 22:37:48', ' ', '', '', 'publish', 'closed', 'closed', '', '98', '', '', '2016-05-27 14:57:02', '2016-05-27 21:57:02', '', 0, 'http://localhost/student/?p=98', 3, 'nav_menu_item', '', 0),
(99, 1, '2016-05-24 15:37:48', '2016-05-24 22:37:48', ' ', '', '', 'publish', 'closed', 'closed', '', '99', '', '', '2016-05-27 14:57:02', '2016-05-27 21:57:02', '', 0, 'http://localhost/student/?p=99', 4, 'nav_menu_item', '', 0),
(100, 1, '2016-05-24 15:36:48', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-05-24 15:36:48', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=100', 1, 'nav_menu_item', '', 0),
(101, 1, '2016-05-24 15:37:48', '2016-05-24 22:37:48', ' ', '', '', 'publish', 'closed', 'closed', '', 'journal', '', '', '2016-05-27 14:57:02', '2016-05-27 21:57:02', '', 0, 'http://localhost/student/?p=101', 2, 'nav_menu_item', '', 0),
(102, 1, '2016-05-24 15:36:49', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-05-24 15:36:49', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=102', 1, 'nav_menu_item', '', 0),
(103, 1, '2016-05-24 15:37:47', '2016-05-24 22:37:47', '', 'Shop', '', 'publish', 'closed', 'closed', '', 'shop', '', '', '2016-05-27 14:57:02', '2016-05-27 21:57:02', '', 0, 'http://localhost/student/?p=103', 1, 'nav_menu_item', '', 0),
(104, 1, '2016-05-24 15:39:29', '2016-05-24 22:39:29', '', 'Journal', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2016-05-24 15:39:29', '2016-05-24 22:39:29', '', 18, 'http://localhost/student/2016/05/24/18-revision-v1/', 0, 'revision', '', 0),
(105, 1, '2016-05-24 15:40:52', '2016-05-24 22:40:52', '', 'Contact', '', 'inherit', 'closed', 'closed', '', '14-revision-v1', '', '', '2016-05-24 15:40:52', '2016-05-24 22:40:52', '', 14, 'http://localhost/student/2016/05/24/14-revision-v1/', 0, 'revision', '', 0),
(106, 1, '2016-05-24 15:52:03', '2016-05-24 22:52:03', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Beach Tent', '', 'publish', 'closed', 'closed', '', 'beach-tent', '', '', '2016-06-01 10:47:06', '2016-06-01 17:47:06', '', 0, 'http://localhost/student/?post_type=product&#038;p=106', 0, 'product', '', 0),
(107, 1, '2016-05-24 15:52:03', '2016-05-24 22:52:03', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Beach Tent', '', 'inherit', 'closed', 'closed', '', '106-revision-v1', '', '', '2016-05-24 15:52:03', '2016-05-24 22:52:03', '', 106, 'http://localhost/student/2016/05/24/106-revision-v1/', 0, 'revision', '', 0),
(108, 1, '2016-05-24 15:54:06', '2016-05-24 22:54:06', '&nbsp;\r\n\r\nGastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Camper Van', '', 'publish', 'closed', 'closed', '', 'camper-van', '', '', '2016-06-01 10:46:51', '2016-06-01 17:46:51', '', 0, 'http://localhost/student/?post_type=product&#038;p=108', 0, 'product', '', 0),
(109, 1, '2016-05-24 15:54:06', '2016-05-24 22:54:06', '&nbsp;\r\n\r\nGastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Camper Van', '', 'inherit', 'closed', 'closed', '', '108-revision-v1', '', '', '2016-05-24 15:54:06', '2016-05-24 22:54:06', '', 108, 'http://localhost/student/2016/05/24/108-revision-v1/', 0, 'revision', '', 0) ;
INSERT INTO `qwenjt_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(110, 1, '2016-05-24 15:55:35', '2016-05-24 22:55:35', '&nbsp;\r\n\r\n&nbsp;\r\n\r\nGastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Ceramic Mug', '', 'publish', 'closed', 'closed', '', 'ceramic-mug', '', '', '2016-06-01 10:47:09', '2016-06-01 17:47:09', '', 0, 'http://localhost/student/?post_type=product&#038;p=110', 0, 'product', '', 0),
(111, 1, '2016-05-24 15:55:35', '2016-05-24 22:55:35', '&nbsp;\r\n\r\n&nbsp;\r\n\r\nGastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Ceramic Mug', '', 'inherit', 'closed', 'closed', '', '110-revision-v1', '', '', '2016-05-24 15:55:35', '2016-05-24 22:55:35', '', 110, 'http://localhost/student/2016/05/24/110-revision-v1/', 0, 'revision', '', 0),
(112, 1, '2016-05-24 15:56:14', '2016-05-24 22:56:14', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Film Camera', '', 'publish', 'closed', 'closed', '', 'film-camera', '', '', '2016-06-01 10:46:16', '2016-06-01 17:46:16', '', 0, 'http://localhost/student/?post_type=product&#038;p=112', 0, 'product', '', 0),
(113, 1, '2016-05-24 15:56:14', '2016-05-24 22:56:14', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Film Camera', '', 'inherit', 'closed', 'closed', '', '112-revision-v1', '', '', '2016-05-24 15:56:14', '2016-05-24 22:56:14', '', 112, 'http://localhost/student/2016/05/24/112-revision-v1/', 0, 'revision', '', 0),
(114, 1, '2016-05-24 15:57:21', '2016-05-24 22:57:21', '&nbsp;\r\n\r\nGastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Flannel Shirt', '', 'publish', 'closed', 'closed', '', 'flannel-shirt', '', '', '2016-06-01 10:45:52', '2016-06-01 17:45:52', '', 0, 'http://localhost/student/?post_type=product&#038;p=114', 0, 'product', '', 0),
(115, 1, '2016-05-24 15:57:21', '2016-05-24 22:57:21', '&nbsp;\r\n\r\nGastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Flannel Shirt', '', 'inherit', 'closed', 'closed', '', '114-revision-v1', '', '', '2016-05-24 15:57:21', '2016-05-24 22:57:21', '', 114, 'http://localhost/student/2016/05/24/114-revision-v1/', 0, 'revision', '', 0),
(116, 1, '2016-05-24 15:57:55', '2016-05-24 22:57:55', '&nbsp;\r\n\r\nGastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Gas Stove', '', 'publish', 'closed', 'closed', '', 'gas-stove', '', '', '2016-06-01 10:45:30', '2016-06-01 17:45:30', '', 0, 'http://localhost/student/?post_type=product&#038;p=116', 0, 'product', '', 0),
(117, 1, '2016-05-24 15:57:55', '2016-05-24 22:57:55', '&nbsp;\r\n\r\nGastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Gas Stove', '', 'inherit', 'closed', 'closed', '', '116-revision-v1', '', '', '2016-05-24 15:57:55', '2016-05-24 22:57:55', '', 116, 'http://localhost/student/2016/05/24/116-revision-v1/', 0, 'revision', '', 0),
(118, 1, '2016-05-24 15:58:38', '2016-05-24 22:58:38', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Hand-Knit Toque', '', 'publish', 'closed', 'closed', '', 'hand-knit-toque', '', '', '2016-06-01 10:45:08', '2016-06-01 17:45:08', '', 0, 'http://localhost/student/?post_type=product&#038;p=118', 0, 'product', '', 0),
(119, 1, '2016-05-24 15:58:38', '2016-05-24 22:58:38', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Hand-Knit Toque', '', 'inherit', 'closed', 'closed', '', '118-revision-v1', '', '', '2016-05-24 15:58:38', '2016-05-24 22:58:38', '', 118, 'http://localhost/student/2016/05/24/118-revision-v1/', 0, 'revision', '', 0),
(120, 1, '2016-05-24 16:00:43', '2016-05-24 23:00:43', '&nbsp;\r\n\r\nGastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Hiking Boots', '', 'publish', 'closed', 'closed', '', 'hiking-boots', '', '', '2016-05-29 14:22:31', '2016-05-29 21:22:31', '', 0, 'http://localhost/student/?post_type=product&#038;p=120', 0, 'product', '', 0),
(121, 1, '2016-05-24 16:00:43', '2016-05-24 23:00:43', '&nbsp;\r\n\r\nGastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Hiking Boots', '', 'inherit', 'closed', 'closed', '', '120-revision-v1', '', '', '2016-05-24 16:00:43', '2016-05-24 23:00:43', '', 120, 'http://localhost/student/2016/05/24/120-revision-v1/', 0, 'revision', '', 0),
(122, 1, '2016-05-24 16:01:39', '2016-05-24 23:01:39', '&nbsp;\r\n\r\n&nbsp;\r\n\r\nGastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Large Thermos', '', 'publish', 'closed', 'closed', '', 'large-thermos', '', '', '2016-05-29 14:21:52', '2016-05-29 21:21:52', '', 0, 'http://localhost/student/?post_type=product&#038;p=122', 0, 'product', '', 0),
(123, 1, '2016-05-24 16:01:39', '2016-05-24 23:01:39', '&nbsp;\r\n\r\n&nbsp;\r\n\r\nGastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Large Thermos', '', 'inherit', 'closed', 'closed', '', '122-revision-v1', '', '', '2016-05-24 16:01:39', '2016-05-24 23:01:39', '', 122, 'http://localhost/student/2016/05/24/122-revision-v1/', 0, 'revision', '', 0),
(124, 1, '2016-05-24 16:02:25', '2016-05-24 23:02:25', '&nbsp;\r\n\r\nGastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Leather Satchel', '', 'publish', 'closed', 'closed', '', 'leather-satchel', '', '', '2016-05-29 14:21:17', '2016-05-29 21:21:17', '', 0, 'http://localhost/student/?post_type=product&#038;p=124', 0, 'product', '', 0),
(125, 1, '2016-05-24 16:02:25', '2016-05-24 23:02:25', '&nbsp;\r\n\r\nGastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Leather Satchel', '', 'inherit', 'closed', 'closed', '', '124-revision-v1', '', '', '2016-05-24 16:02:25', '2016-05-24 23:02:25', '', 124, 'http://localhost/student/2016/05/24/124-revision-v1/', 0, 'revision', '', 0),
(126, 1, '2016-05-24 16:03:01', '2016-05-24 23:03:01', '&nbsp;\r\n\r\nGastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Nylon Tents', '', 'publish', 'closed', 'closed', '', 'nylon-tents', '', '', '2016-05-29 14:20:39', '2016-05-29 21:20:39', '', 0, 'http://localhost/student/?post_type=product&#038;p=126', 0, 'product', '', 0),
(127, 1, '2016-05-24 16:03:01', '2016-05-24 23:03:01', '&nbsp;\r\n\r\nGastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Nylon Tents', '', 'inherit', 'closed', 'closed', '', '126-revision-v1', '', '', '2016-05-24 16:03:01', '2016-05-24 23:03:01', '', 126, 'http://localhost/student/2016/05/24/126-revision-v1/', 0, 'revision', '', 0),
(128, 1, '2016-05-24 16:03:48', '2016-05-24 23:03:48', 'Rustic Tools\r\n\r\nGastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Rustic Tools', '', 'publish', 'closed', 'closed', '', 'rustic-tools', '', '', '2016-05-27 15:14:10', '2016-05-27 22:14:10', '', 0, 'http://localhost/student/?post_type=product&#038;p=128', 0, 'product', '', 0),
(129, 1, '2016-05-24 16:03:48', '2016-05-24 23:03:48', 'Rustic Tools\r\n\r\nGastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Rustic Tools', '', 'inherit', 'closed', 'closed', '', '128-revision-v1', '', '', '2016-05-24 16:03:48', '2016-05-24 23:03:48', '', 128, 'http://localhost/student/2016/05/24/128-revision-v1/', 0, 'revision', '', 0),
(130, 1, '2016-05-24 16:04:27', '2016-05-24 23:04:27', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Stew Can', '', 'publish', 'closed', 'closed', '', 'stew-can', '', '', '2016-05-27 15:13:09', '2016-05-27 22:13:09', '', 0, 'http://localhost/student/?post_type=product&#038;p=130', 0, 'product', '', 0),
(131, 1, '2016-05-24 16:04:27', '2016-05-24 23:04:27', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Stew Can', '', 'inherit', 'closed', 'closed', '', '130-revision-v1', '', '', '2016-05-24 16:04:27', '2016-05-24 23:04:27', '', 130, 'http://localhost/student/2016/05/24/130-revision-v1/', 0, 'revision', '', 0),
(132, 1, '2016-05-24 16:05:11', '2016-05-24 23:05:11', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Travel Hammock', '', 'publish', 'closed', 'closed', '', 'travel-hammock', '', '', '2016-05-27 15:12:44', '2016-05-27 22:12:44', '', 0, 'http://localhost/student/?post_type=product&#038;p=132', 0, 'product', '', 0),
(133, 1, '2016-05-24 16:05:11', '2016-05-24 23:05:11', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Travel Hammock', '', 'inherit', 'closed', 'closed', '', '132-revision-v1', '', '', '2016-05-24 16:05:11', '2016-05-24 23:05:11', '', 132, 'http://localhost/student/2016/05/24/132-revision-v1/', 0, 'revision', '', 0),
(134, 1, '2016-05-24 16:05:50', '2016-05-24 23:05:50', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Weathered Canoes', '', 'publish', 'closed', 'closed', '', 'weathered-canoes', '', '', '2016-05-27 15:12:13', '2016-05-27 22:12:13', '', 0, 'http://localhost/student/?post_type=product&#038;p=134', 0, 'product', '', 0),
(135, 1, '2016-05-24 16:05:50', '2016-05-24 23:05:50', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Weathered Canoes', '', 'inherit', 'closed', 'closed', '', '134-revision-v1', '', '', '2016-05-24 16:05:50', '2016-05-24 23:05:50', '', 134, 'http://localhost/student/2016/05/24/134-revision-v1/', 0, 'revision', '', 0),
(136, 1, '2016-05-24 16:06:38', '2016-05-24 23:06:38', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Wood Axe', '', 'publish', 'closed', 'closed', '', 'wood-axe', '', '', '2016-05-27 15:11:48', '2016-05-27 22:11:48', '', 0, 'http://localhost/student/?post_type=product&#038;p=136', 0, 'product', '', 0),
(137, 1, '2016-05-24 16:06:38', '2016-05-24 23:06:38', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Wood Axx', '', 'inherit', 'closed', 'closed', '', '136-revision-v1', '', '', '2016-05-24 16:06:38', '2016-05-24 23:06:38', '', 136, 'http://localhost/student/2016/05/24/136-revision-v1/', 0, 'revision', '', 0),
(138, 1, '2016-05-24 16:07:28', '2016-05-24 23:07:28', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Wood Axe', '', 'inherit', 'closed', 'closed', '', '136-revision-v1', '', '', '2016-05-24 16:07:28', '2016-05-24 23:07:28', '', 136, 'http://localhost/student/2016/05/24/136-revision-v1/', 0, 'revision', '', 0),
(139, 1, '2016-05-25 10:01:06', '2016-05-25 17:01:06', '', 'About Page', '', 'trash', 'closed', 'closed', '', '__trashed', '', '', '2016-05-25 10:25:52', '2016-05-25 17:25:52', '', 0, 'http://localhost/student/?post_type=cfs&#038;p=139', 0, 'cfs', '', 0),
(140, 1, '2016-05-25 10:03:57', '2016-05-25 17:03:57', '', 'About Page', '', 'publish', 'closed', 'closed', '', 'about-page', '', '', '2016-05-27 13:56:56', '2016-05-27 20:56:56', '', 0, 'http://localhost/student/?post_type=cfs&#038;p=140', 0, 'cfs', '', 0),
(141, 1, '2016-05-25 10:09:09', '2016-05-25 17:09:09', '', 'about-hero', '', 'inherit', 'open', 'closed', '', 'about-hero', '', '', '2016-05-25 10:09:09', '2016-05-25 17:09:09', '', 10, 'http://localhost/student/wp-content/uploads/2016/05/about-hero.jpg', 0, 'attachment', 'image/jpeg', 0),
(142, 1, '2016-05-25 10:22:04', '2016-05-25 17:22:04', 'Our Story\r\n\r\n&nbsp;\r\n\r\nInhabitent Camping Supply Co. has been Vancouver baked-good icon for more than two whole months! Customers often comment on the bustle of activity they see in store…that’s where the magic happens every day.\r\n\r\n&nbsp;\r\n\r\nWe want to bridge the gap between the comfort of city life and the lovely Instagram-worthiness of the great outdoors that surround us. We sell gear that’s fun and functional. So much fun, in fact, that you’ll want to pitch a tent inside your one-bedroom apartment so you can use it everyday.\r\n\r\n&nbsp;\r\n<h2></h2>', 'About', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2016-05-25 10:22:04', '2016-05-25 17:22:04', '', 10, 'http://localhost/student/2016/05/25/10-revision-v1/', 0, 'revision', '', 0),
(143, 1, '2016-05-26 11:54:58', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-05-26 11:54:58', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=143', 0, 'post', '', 0),
(144, 1, '2016-05-27 11:20:01', '2016-05-27 18:20:01', 'Inhabitent Camping Supply Co. has been Vancouver baked-good icon for more than two whole months! Customers often comment on the bustle of activity they see in store…that’s where the magic happens every day.\r\n\r\n&nbsp;\r\n\r\nWe want to bridge the gap between the comfort of city life and the lovely Instagram-worthiness of the great outdoors that surround us. We sell gear that’s fun and functional. So much fun, in fact, that you’ll want to pitch a tent inside your one-bedroom apartment so you can use it everyday.\r\n\r\n&nbsp;\r\n<h2></h2>', 'About', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2016-05-27 11:20:01', '2016-05-27 18:20:01', '', 10, 'http://localhost/student/2016/05/27/10-revision-v1/', 0, 'revision', '', 0),
(145, 1, '2016-05-27 11:24:06', '2016-05-27 18:24:06', '&nbsp;\r\n\r\n&nbsp;\r\n<h2></h2>', 'About', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2016-05-27 11:24:06', '2016-05-27 18:24:06', '', 10, 'http://localhost/student/2016/05/27/10-revision-v1/', 0, 'revision', '', 0),
(147, 1, '2016-05-27 15:00:47', '2016-05-27 22:00:47', '<img src="http://localhost/student/wp-content/uploads/2016/05/wood-ax-300x200.jpg" alt="wood-ax" width="300" height="200" class="alignnone size-medium wp-image-75" />Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Wood Axe', '', 'inherit', 'closed', 'closed', '', '136-revision-v1', '', '', '2016-05-27 15:00:47', '2016-05-27 22:00:47', '', 136, 'http://localhost/student/2016/05/27/136-revision-v1/', 0, 'revision', '', 0),
(148, 1, '2016-05-27 15:11:36', '2016-05-27 22:11:36', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Wood Axe', '', 'inherit', 'closed', 'closed', '', '136-revision-v1', '', '', '2016-05-27 15:11:36', '2016-05-27 22:11:36', '', 136, 'http://localhost/student/2016/05/27/136-revision-v1/', 0, 'revision', '', 0) ;

#
# End of data contents of table `qwenjt_posts`
# --------------------------------------------------------



#
# Delete any existing table `qwenjt_term_relationships`
#

DROP TABLE IF EXISTS `qwenjt_term_relationships`;


#
# Table structure of table `qwenjt_term_relationships`
#

CREATE TABLE `qwenjt_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `qwenjt_term_relationships`
#
INSERT INTO `qwenjt_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(32, 2, 0),
(32, 3, 0),
(32, 4, 0),
(35, 5, 0),
(35, 6, 0),
(35, 7, 0),
(39, 5, 0),
(39, 8, 0),
(39, 9, 0),
(41, 10, 0),
(41, 11, 0),
(45, 10, 0),
(45, 11, 0),
(45, 12, 0),
(98, 14, 0),
(99, 14, 0),
(101, 14, 0),
(103, 14, 0),
(106, 15, 0),
(108, 15, 0),
(110, 16, 0),
(112, 17, 0),
(114, 18, 0),
(116, 16, 0),
(118, 18, 0),
(120, 18, 0),
(122, 16, 0),
(124, 18, 0),
(126, 15, 0),
(128, 17, 0),
(130, 16, 0),
(132, 15, 0),
(134, 17, 0),
(136, 17, 0) ;

#
# End of data contents of table `qwenjt_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `qwenjt_term_taxonomy`
#

DROP TABLE IF EXISTS `qwenjt_term_taxonomy`;


#
# Table structure of table `qwenjt_term_taxonomy`
#

CREATE TABLE `qwenjt_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `qwenjt_term_taxonomy`
#
INSERT INTO `qwenjt_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'category', '', 0, 1),
(3, 3, 'post_tag', '', 0, 1),
(4, 4, 'post_tag', '', 0, 1),
(5, 5, 'category', '', 0, 2),
(6, 6, 'post_tag', '', 0, 1),
(7, 7, 'post_tag', '', 0, 1),
(8, 8, 'post_tag', '', 0, 1),
(9, 9, 'post_tag', '', 0, 1),
(10, 10, 'category', '', 0, 2),
(11, 11, 'post_tag', '', 0, 2),
(12, 12, 'category', '', 0, 1),
(14, 14, 'nav_menu', '', 0, 4),
(15, 15, 'product-type', 'over? sounds fun', 0, 4),
(16, 16, 'product-type', 'like there\'s plenty of pizza', 0, 4),
(17, 17, 'product-type', 'of do not, there is no try', 0, 4),
(18, 18, 'product-type', 'iors. come out to play-ee-ay', 0, 4) ;

#
# End of data contents of table `qwenjt_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `qwenjt_termmeta`
#

DROP TABLE IF EXISTS `qwenjt_termmeta`;


#
# Table structure of table `qwenjt_termmeta`
#

CREATE TABLE `qwenjt_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `qwenjt_termmeta`
#

#
# End of data contents of table `qwenjt_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `qwenjt_terms`
#

DROP TABLE IF EXISTS `qwenjt_terms`;


#
# Table structure of table `qwenjt_terms`
#

CREATE TABLE `qwenjt_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `qwenjt_terms`
#
INSERT INTO `qwenjt_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Contests', 'contests', 0),
(3, 'Photography', 'photography', 0),
(4, 'Vans', 'vans', 0),
(5, 'Recipes', 'recipes', 0),
(6, 'Campfires', 'campfires', 0),
(7, 'Drinks', 'drinks', 0),
(8, 'Food', 'food', 0),
(9, 'Healthy', 'healthy', 0),
(10, 'How-tos', 'how-tos', 0),
(11, 'Tenting', 'tenting', 0),
(12, 'Not Really Camping', 'not-really-camping', 0),
(14, 'Menu 1', 'menu-1', 0),
(15, 'Sleep', 'sleep', 0),
(16, 'Eat', 'eat', 0),
(17, 'Do', 'do', 0),
(18, 'Wear', 'wear', 0) ;

#
# End of data contents of table `qwenjt_terms`
# --------------------------------------------------------



#
# Delete any existing table `qwenjt_usermeta`
#

DROP TABLE IF EXISTS `qwenjt_usermeta`;


#
# Table structure of table `qwenjt_usermeta`
#

CREATE TABLE `qwenjt_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `qwenjt_usermeta`
#
INSERT INTO `qwenjt_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'tylerlforbes'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'qwenjt_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(11, 1, 'qwenjt_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', ''),
(13, 1, 'show_welcome_panel', '1'),
(14, 1, 'session_tokens', 'a:1:{s:64:"2f95a297a8ab791ee512ca8f4fe9ce0e94e9ec126ba6b1977c17293c351df1f5";a:4:{s:10:"expiration";i:1465325323;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:110:"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36";s:5:"login";i:1464115723;}}'),
(15, 1, 'qwenjt_dashboard_quick_press_last_post_id', '143'),
(16, 1, 'qwenjt_user-settings', 'editor=html&mfold=o&libraryContent=browse'),
(17, 1, 'qwenjt_user-settings-time', '1464379237'),
(18, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(19, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(20, 1, 'nav_menu_recently_edited', '14'),
(21, 1, 'closedpostboxes_cfs', 'a:0:{}'),
(22, 1, 'metaboxhidden_cfs', 'a:1:{i:0;s:7:"slugdiv";}'),
(23, 1, 'closedpostboxes_post', 'a:0:{}'),
(24, 1, 'metaboxhidden_post', 'a:8:{i:0;s:12:"revisionsdiv";i:1;s:11:"postexcerpt";i:2;s:13:"trackbacksdiv";i:3;s:10:"postcustom";i:4;s:16:"commentstatusdiv";i:5;s:11:"commentsdiv";i:6;s:7:"slugdiv";i:7;s:9:"authordiv";}'),
(25, 2, 'nickname', 'mandi'),
(26, 2, 'first_name', 'mandi'),
(27, 2, 'last_name', ''),
(28, 2, 'description', ''),
(29, 2, 'rich_editing', 'true'),
(30, 2, 'comment_shortcuts', 'false'),
(31, 2, 'admin_color', 'fresh'),
(32, 2, 'use_ssl', '0'),
(33, 2, 'show_admin_bar_front', 'true'),
(34, 2, 'qwenjt_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(35, 2, 'qwenjt_user_level', '10'),
(36, 2, 'dismissed_wp_pointers', '') ;

#
# End of data contents of table `qwenjt_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `qwenjt_users`
#

DROP TABLE IF EXISTS `qwenjt_users`;


#
# Table structure of table `qwenjt_users`
#

CREATE TABLE `qwenjt_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `qwenjt_users`
#
INSERT INTO `qwenjt_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'tylerlforbes', '$P$BnvALPxgBom8hfuRE3eWI11tyV5zvN.', 'tylerlforbes', 'tylerlforbes@gmail.com', '', '2016-05-18 22:54:51', '', 0, 'tylerlforbes'),
(2, 'mandi', '$P$BwoZTiY9bQenzBa7qlP8hI.MnrvdEb0', 'mandi', 'mandi@redacademy.com', '', '2016-06-01 17:58:32', '1464803914:$P$BEgYZCI.S.h3usMTsosJw2pIzCYyzp.', 0, 'mandi') ;

#
# End of data contents of table `qwenjt_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

